# Drupal content model

Set these up as standard Drupal content types under **Structure → Content
types**. All are translatable — enable **Content language and translation**
(core module `content_translation`) globally, then per content type under
**Configuration → Regional and language → Content language**.

## Recommended languages at launch

Matching the countries Vodacom operates in:

| Code | Language   | Region              |
|------|------------|----------------------|
| en   | English    | default / fallback  |
| fr   | French     | DR Congo            |
| pt   | Portuguese | Mozambique          |
| sw   | Swahili    | Tanzania            |
| st   | Sesotho    | Lesotho             |

Add more under **Configuration → Regional and language → Languages** at any
time — no frontend redeploy needed beyond adding the code to
`astro.config.mjs` and `src/i18n/ui.ts`.

## Content type: Page

General-purpose page (homepage, about us, careers landing, etc).

| Field                | Machine name           | Type              | Translatable |
|-----------------------|------------------------|-------------------|:---:|
| Title                 | `title`                | Text              | ✅ |
| Hero headline         | `field_hero_headline`  | Text              | ✅ |
| Hero subhead          | `field_hero_subhead`   | Text              | ✅ |
| Hero image            | `field_hero_image`     | Media (image)     | ✅ (per-locale image allowed, or shared) |
| Hero video            | `field_hero_video`     | Media (video)     | shared across locales |
| Body                  | `body`                 | Long text (CKEditor) | ✅ |
| SEO title             | `field_seo_title`      | Text              | ✅ |
| SEO description       | `field_seo_description`| Text              | ✅ |
| URL alias             | (Path field)           | built-in          | ✅ per-locale slug |

## Content type: Media release

Fields expanded to match the legacy `articles` table exactly (from
`includes/latest-news.php`), so nothing is lost in the move to Drupal:

| Field           | Machine name          | Type          | Translatable |
|------------------|------------------------|---------------|:---:|
| Title            | `title`                | Text          | ✅ |
| Published date   | `field_published_date` | Date          | shared |
| Intro            | `field_intro`          | Text          | ✅ |
| Body             | `body`                 | Long text     | ✅ (optional — some releases are just a downloadable doc or external link) |
| Small image      | `field_small_image`    | Media (image) | shared |
| Large image      | `field_large_image`    | Media (image) | shared |
| Document         | `field_document`       | Media (file)  | shared |
| External link    | `field_external_link`  | Link          | shared (some releases point off-site instead of to a local article) |
| Source           | `field_source`         | Text          | shared |
| Category         | `field_category`       | Taxonomy ref  | shared |
| Subcategory      | `field_subcategory`    | Taxonomy ref  | shared |
| Featured         | `field_featured`       | Boolean       | shared |
| Disclaimer       | `field_disclaimer`     | Long text     | ✅ |

## Content type: Investor event

Replaces the legacy `calendarEvent` MySQL table (`calendar.php` ran a raw
SQL query against it directly) with an editable content type.

| Field        | Machine name         | Type   | Translatable |
|---------------|------------------------|--------|:---:|
| Title         | `title`                | Text   | ✅ |
| Event start   | `field_event_start`    | Date   | shared |
| Event end     | `field_event_end`      | Date   | shared |
| Location      | `field_location`       | Text   | ✅ |
| Time          | `field_time`           | Text   | shared |

## Content type: Board member

Split out from Executive profile — legacy `board-of-directors.php` shows
board members need age, qualifications, and multiple committee
memberships, which don't apply to the executive committee.

| Field           | Machine name          | Type          | Translatable |
|------------------|------------------------|---------------|:---:|
| Name             | `title`                | Text          | shared |
| Age              | `field_age`            | Number        | shared |
| Role             | `field_role`           | Text          | ✅ |
| Qualifications    | `field_qualifications` | Text          | ✅ |
| Committees        | `field_committees`     | Text (multi-value) | ✅ |
| Photo             | `field_photo`          | Media (image) | shared |
| Bio               | `body`                 | Long text     | ✅ |
| Order             | `field_order`          | Number        | shared |

## Content type: Job listing

| Field           | Machine name        | Type       | Translatable |
|------------------|-----------------------|------------|:---:|
| Title            | `title`               | Text       | ✅ |
| Location         | `field_location`      | Text       | ✅ |
| Department       | `field_department`    | Taxonomy ref | ✅ |
| Closing date     | `field_closing_date`  | Date       | shared |
| Apply URL        | `field_apply_url`     | Link       | shared (usually points at careers.vodafone.com ATS) |
| Body             | `body`                | Long text  | ✅ |

## Content type: Executive profile

Distinct from Board member (above) — simpler, no age/qualifications/committees.

| Field   | Machine name    | Type          | Translatable |
|----------|------------------|---------------|:---:|
| Name     | `title`          | Text          | shared |
| Role     | `field_role`     | Text          | ✅ |
| Photo    | `field_photo`    | Media (image) | shared |
| Bio      | `body`           | Long text     | ✅ |
| Order    | `field_order`    | Number        | shared |

## Media library requirements

- Every image field is **required to have alt text** before publishing —
  enforce this with Drupal's built-in required-field validation. This is
  both an accessibility requirement and prevents editors from accidentally
  shipping large unoptimized images with no fallback text.
- Set Drupal's image styles to output responsive image sets (`Configuration
  → Media → Image styles`) even though Astro re-optimizes at build time —
  this keeps the Drupal admin preview reasonably fast too, and gives a
  sane source resolution ceiling (recommend capping originals at 2400px
  wide on upload).

## Editorial workflow

Use core **Content moderation** (Draft → Review → Published) so
non-technical editors can save drafts without triggering a rebuild, and a
rebuild only fires on the transition to **Published** — this is also where
the webhook to CI should be attached (**Configuration → Workflow →
Content moderation**, or a custom Rules action).

## Paragraphs / flexible sections

Beyond the fixed content types above, `Page` also supports a
**Paragraphs** field (`field_sections`) — this is what lets an editor
build a new page by picking and stacking reusable blocks, rather than
being locked into one rigid layout. Create one Paragraph type per row
below, with the listed fields. Each maps to exactly one Astro component
(see `src/components/SectionRenderer.astro`).

| Paragraph type | Fields | When an editor picks it |
|---|---|---|
| **Rich text** | Body (long text) | Default — general prose, headings, lists |
| **Related links grid** | Heading (text), Cards (nested paragraph, unlimited — see below) | 2–4 image cards linking to sibling pages |
| **Expandable card grid** | Heading, Columns (2 or 3), Cards (nested paragraph, unlimited) | A grid of cards that expand in place for more detail (bios, sub-topics) |
| **Accordion** | Items (nested paragraph, unlimited) | Stacked collapsible sections |
| **Process flow** | Steps (nested paragraph, unlimited) | A numbered sequence shown vertically with connecting arrows |
| **Icon link grid** | Heading, Items (nested paragraph, unlimited) | CTA cards with an icon, often linking off-site |
| **Callout banner** | Message, CTA label, CTA link, Tone (red/dark) | A full-width colored band for an important message |
| **Document download list** | Heading, Documents (nested paragraph, unlimited) | A stack of PDF/file download buttons |
| **Related link list** | Links (nested paragraph, unlimited) | A flat list of "read more →" links |
| **Share price widget** | (no fields — always renders the live embed) | Investor-relations pages |

### Why some of these need a *nested* paragraph

A repeating group of mixed fields (a card needs an image **and** a label
**and** a link, repeated as a unit) can't be modeled as a single Drupal
multi-value field — Drupal's multi-value fields repeat one field type,
not a bundle of different ones. The fix is a **second, smaller Paragraph
type** referenced by the first via an entity-reference-revisions field,
which is what "nested paragraph" means below. This is the one available
native pattern for this in Drupal (not a stylistic choice) — it also keeps
editors in a single consistent workflow: everything is "click Add, fill
the fields, drag to reorder," whether it's a top-level section or an item
inside one.

Create these nested Paragraph types, each referenced by its parent above
via a `field_cards` / `field_items` / `field_steps` / `field_documents` /
`field_links` entity-reference-revisions field (unlimited values):

| Nested Paragraph type | Referenced by | Fields |
|---|---|---|
| `link_card` | Related links grid's `field_cards` | Image (media), Label (text), Link (link field) |
| `expandable_card` | Expandable card grid's `field_cards` | Title, Subtitle (optional text), Image (media, optional), Image shape (list: circle/square), Body (long text) |
| `accordion_item` | Accordion's `field_items` | Icon (text — a path/URL, not a media reference), Title, Teaser (one-line text), Body (long text) |
| `process_step` | Process flow's `field_steps` | Title, Description (optional long text) |
| `icon_link_item` | Icon link grid's `field_items` | Icon (text path/URL), Label, Link (link field), External (boolean) |
| `document_item` | Document download list's `field_documents` | Label (text), File (file field — size is read automatically, not entered by the editor) |
| `link_item` | Related link list's `field_links` | Label (text), Link (link field) |

An editor building a new page adds `field_sections` values one at a time,
picking from the top-level list each time; for any section with
repeating items, an "Add another" button appears inside it for the nested
type — exactly like adding blocks in a modern page builder, just one
level deeper for grids/lists. See `docs/EDITOR_GUIDE.md` for the
editor-facing walkthrough.


