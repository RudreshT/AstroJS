// UI chrome strings only (nav labels, buttons, footer). Page CONTENT
// (headlines, body copy, media releases, job listings) is translated by
// editors in Drupal, not here — this file just covers the frontend shell
// text that isn't tied to a CMS entity.
//
// To add a language: add a key here, add a locale to astro.config.mjs, and
// tell the content team a new language is enabled for translation in Drupal.

export const defaultLang = 'en';

export const ui = {
  en: {
    'nav.about': 'About us',
    'nav.whatWeDo': 'What we do',
    'nav.purpose': 'Our purpose & ESG',
    'nav.investors': 'Investor relations',
    'nav.media': 'Media',
    'nav.careers': 'Careers',
    'nav.contact': 'Contact us',
    'nav.search': 'Search',
    'nav.language': 'Choose your language',
    'cta.readMore': 'Read more',
    'cta.learnMore': 'Learn more',
    'footer.rights': 'All rights reserved',
    'a11y.skipToContent': 'Skip to main content',
  },
  fr: {
    'nav.about': 'À propos',
    'nav.whatWeDo': 'Nos activités',
    'nav.purpose': 'Notre raison d\u2019être & ESG',
    'nav.investors': 'Relations investisseurs',
    'nav.media': 'Médias',
    'nav.careers': 'Carrières',
    'nav.contact': 'Contactez-nous',
    'nav.search': 'Rechercher',
    'nav.language': 'Choisissez votre langue',
    'cta.readMore': 'En savoir plus',
    'cta.learnMore': 'En savoir plus',
    'footer.rights': 'Tous droits réservés',
    'a11y.skipToContent': 'Aller au contenu principal',
  },
  pt: {
    'nav.about': 'Sobre nós',
    'nav.whatWeDo': 'O que fazemos',
    'nav.purpose': 'Nosso propósito e ESG',
    'nav.investors': 'Relações com investidores',
    'nav.media': 'Media',
    'nav.careers': 'Carreiras',
    'nav.contact': 'Contacte-nos',
    'nav.search': 'Pesquisar',
    'nav.language': 'Escolha o seu idioma',
    'cta.readMore': 'Saiba mais',
    'cta.learnMore': 'Saiba mais',
    'footer.rights': 'Todos os direitos reservados',
    'a11y.skipToContent': 'Ir para o conteúdo principal',
  },
  sw: {
    'nav.about': 'Kuhusu sisi',
    'nav.whatWeDo': 'Tunachofanya',
    'nav.purpose': 'Kusudi letu na ESG',
    'nav.investors': 'Mahusiano ya wawekezaji',
    'nav.media': 'Vyombo vya habari',
    'nav.careers': 'Kazi',
    'nav.contact': 'Wasiliana nasi',
    'nav.search': 'Tafuta',
    'nav.language': 'Chagua lugha yako',
    'cta.readMore': 'Soma zaidi',
    'cta.learnMore': 'Jifunze zaidi',
    'footer.rights': 'Haki zote zimehifadhiwa',
    'a11y.skipToContent': 'Nenda kwenye maudhui makuu',
  },
  st: {
    'nav.about': 'Ka rona',
    'nav.whatWeDo': 'Seo re se etsang',
    'nav.purpose': 'Morero wa rona le ESG',
    'nav.investors': 'Dikamano tsa batsetedi',
    'nav.media': 'Boralitaba',
    'nav.careers': 'Mesebetsi',
    'nav.contact': 'Re ikopanye',
    'nav.search': 'Batla',
    'nav.language': 'Kgetha puo ya hao',
    'cta.readMore': 'Bala haholoanyane',
    'cta.learnMore': 'Ithute haholoanyane',
    'footer.rights': 'Ditokelo tsohle di sireletsehile',
    'a11y.skipToContent': 'Ea ho diteng tse ka hare',
  },
} as const;

export type Lang = keyof typeof ui;

export function useTranslations(lang: string) {
  const dict = ui[lang as Lang] ?? ui[defaultLang];
  return function t(key: keyof typeof ui['en']): string {
    return dict[key] ?? ui[defaultLang][key] ?? key;
  };
}
