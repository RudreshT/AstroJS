import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import vercel from '@astrojs/vercel/serverless';

// Swap the adapter import above for @astrojs/netlify or @astrojs/cloudflare
// if deploying elsewhere — whichever host you pick from
// docs/ARCHITECTURE.md's "Deploy to a CDN" step needs its adapter here so
// the one dynamic preview route (see below) actually has somewhere to run.

// Full locale list is intentionally small at launch; add more once content
// translation workflow is proven in Drupal. Each code must have a matching
// entry in src/i18n/ui.ts and a translated content set in Drupal.
export const locales = {
  en: 'en-ZA', // English (default / fallback)
  fr: 'fr-CD', // French (DR Congo)
  pt: 'pt-MZ', // Portuguese (Mozambique)
  sw: 'sw-TZ', // Swahili (Tanzania)
  st: 'st-LS', // Sesotho (Lesotho)
};

export default defineConfig({
  site: 'https://www.vodacom.com',
  // 'hybrid': static by default, EXCEPT routes that explicitly opt in to
  // on-demand rendering via `export const prerender = false` (used only by
  // src/pages/preview/[id].astro). Every public page is unaffected — this
  // exists purely so editors can preview an unpublished draft without
  // waiting for a full site rebuild. See docs/PREVIEW.md.
  output: 'hybrid',
  build: {
    inlineStylesheets: 'auto', // inline small critical CSS, link the rest
  },
  image: {
    // Astro's built-in image service (sharp) generates AVIF/WebP + responsive
    // sizes at build time so no runtime image processing cost is paid by users
    service: { entrypoint: 'astro/assets/services/sharp' },
  },
  // NOTE: routing is done manually (src/pages/*.astro for English at the
  // root, src/pages/[lang]/*.astro for other locales) rather than via
  // Astro's built-in `i18n` routing config. An earlier attempt to use an
  // optional-bracket directory (`src/pages/[[lang]]/`) is NOT valid Astro
  // syntax for directories and broke the build; this manual two-tier
  // wrapper+template approach (see src/templates/) is the fix.
  //
  // @astrojs/sitemap was also removed here: it expects Astro's native i18n
  // routing config to describe every locale's routes, and threw a build
  // -breaking error against this manual routing setup. Re-add it once
  // either (a) this migrates to Astro's built-in i18n routing, or (b) a
  // hand-rolled sitemap.xml is generated from src/data/siteStructure.ts
  // instead (recommended — that file is already the single source of
  // truth for the page list).
  integrations: [tailwind({ applyBaseStyles: false })],
  adapter: vercel(),
  vite: {
    server: {
      allowedHosts: ['connectu.ddev.site', 'newvodacomsite.ddev.site'],
    },
  },
});

