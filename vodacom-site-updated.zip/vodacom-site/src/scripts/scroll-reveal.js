// Marks JS as available (see the html.js gate in global.css's scroll-reveal
// rules) and reveals [data-reveal] elements as they scroll into view.
// Runs once per page; safe to include on every page even if that page has
// no [data-reveal] elements (the querySelectorAll below is just empty).
document.documentElement.classList.add('js');

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (!reduceMotion) {
  const io = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      }
    },
    { threshold: 0.15, rootMargin: '0px 0px -40px 0px' },
  );
  document.querySelectorAll('[data-reveal]').forEach((el) => io.observe(el));
}
