# SA ConnectU headless frontend
#
# Drupal CMS: https://sa-connectu.ddev.site
# Astro frontend (dev): http://localhost:4321
#
# Quick start
#   cd frontend && npm install && npm run dev
#
# Editors
#   1. Log into Drupal as content_creator / content_approver
#   2. Create/edit Landing page content
#   3. Submit for review → Approve/Publish
#   4. Preview: /preview?nid=NODE_ID&token=PREVIEW_SECRET
#   5. On publish, configure rebuild_webhook_url in sa_headless.settings
#
# Performance model
#   Public pages are statically generated HTML/CSS (CDN-friendly).
#   Heavy widgets (maps/charts) should be Astro islands loaded on demand.
