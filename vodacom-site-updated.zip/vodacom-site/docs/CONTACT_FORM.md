# Contact form backend

## What was wrong with the legacy version

`contact-us.php`'s call-back form built its SQL insert by concatenating
`$_REQUEST` values directly into the query string — a textbook SQL
injection vulnerability — and sent the message via PHP's `mail()` with no
spam/bot filtering. Neither should be carried forward as-is.

## What replaces it

`ContactForm.astro` POSTs to `/api/contact`. Since the frontend is fully
static, this endpoint is **not** a Drupal route — it's a small serverless
function (Vercel/Netlify/Cloudflare function) sitting alongside the static
site, or a hosted form service (Netlify Forms, Formspree) if you'd rather
not run your own.

Either way, the handler must:

1. **Use parameterized queries** if writing to a database — never string
   concatenation. If using Drupal as the store, a service account with a
   scoped API token calling Drupal's JSON:API to create a
   `webform_submission` (or custom entity) is cleaner than a second
   database.
2. **Reject the request silently (200 OK, no-op) if the honeypot field
   (`website`) is non-empty** — that's a bot, not a real submission.
3. **Validate `email` format and require `name`/`message` server-side** —
   never trust client-side `required` alone.
4. **Rate-limit by IP** (most serverless platforms offer this built-in or
   via a lightweight middleware) to blunt basic spam floods.
5. **Send notification email via a transactional email API** (SendGrid,
   Postmark, AWS SES) rather than raw `mail()` — better deliverability and
   built-in bounce/spam handling.

This is intentionally a thin contract — the actual implementation depends
on which hosting platform you pick in the "Deploy to a CDN" step of the
Drupal setup guide, so it's a short follow-up task once that's decided
rather than something to build speculatively now.
