# Importing content from an existing webpage (e.g. vodacom.com)

Two-stage pipeline, deliberately not one automatic script — see
"Why two stages" below.

## Stage 1: extract

```bash
node scripts/extract-webpage-content.mjs https://vodacom.com/ home
```

Fetches the real page, strips legacy chrome (nav/header/footer/scripts),
groups content at heading boundaries, and writes a **draft** sections file
to `content-import/home.json`. Every section it wasn't confident about
gets a `reviewNote` explaining why — the console output also lists these.

**This never touches Drupal.** It's a local file for you to read.

## Stage 2: review (you, not a script)

Open `content-import/home.json`. For each section:

- Read any `reviewNote` and fix what it's flagging (wrong section type,
  awkward pairing, missing content)
- Rewrite auto-extracted text into your own voice where it reads like a
  scrape rather than real copy — this is the part a script can't do for
  you, and skipping it is exactly how you get a page that's functional
  but not "ultra professional"
- Delete sections that are chrome/noise, not real content
- Check image `src` values — the extractor captures whatever URL was on
  the source page (which may be relative, e.g. `/images/x.jpg`); these
  need to point at real images already uploaded to Drupal's media library,
  since the push script does not upload images automatically (see
  "What this doesn't automate" below)

## Stage 3: push to Drupal

```bash
DRUPAL_BASE_URL=https://newvodacomsite.ddev.site \
DRUPAL_API_USER=content-importer \
DRUPAL_API_PASS=your-password \
node scripts/push-sections-to-drupal.mjs content-import/home.json
```

**Runs as a dry run by default** — prints every request it would make,
writes nothing. Read that output. When it looks right, add `--apply`:

```bash
node scripts/push-sections-to-drupal.mjs content-import/home.json --apply
```

The resulting Page node is always created as a **Draft**, never
auto-published — go review it in Drupal (and via the preview link from
`vodacom_preview`, see `docs/DEVELOPER_SETUP.md`) before publishing.

## Why two stages, not one automatic import

A single "scrape and publish" script optimizes for speed over quality.
Given the "ultra professional" bar this project is held to, that trade
isn't worth it — auto-classified section types and auto-extracted text
need a human pass before they're something you'd want visitors to see.
Splitting extract/review/push means:
- You can fix mistakes before they touch Drupal
- Nothing is ever silently auto-published
- The dry-run step in Stage 3 gives a second checkpoint even after review

## What this doesn't automate (and why)

- **Image upload.** The push script does not fetch and upload images to
  Drupal's media library — that means fetching arbitrary remote files
  into your file system automatically, which is a meaningfully bigger
  risk surface (unvetted file types, size, source trust) than text import.
  Upload images manually in Drupal's media library, then reference their
  real media UUIDs — the script will tell you exactly which cards need
  this via `[manual step needed]` console output.
- **Section types the extractor never produces**: `expandableCardGrid`,
  `accordion`, `processFlow`, `iconLinkGrid`, `documentDownloadList`. A
  generic webpage scrape doesn't reliably detect these patterns (they
  need judgment about what's a "process" vs. what's a "grid"), so the
  extractor only ever emits `richText`, `relatedLinksGrid`, and
  `relatedLinkList`. If you want one of the other types, add it by hand
  directly in Drupal — the push script's `createParagraph()` has a clear
  comment showing where to extend it, following the same pattern as the
  two nested types (`relatedLinksGrid`, `relatedLinkList`) already
  implemented.

## Verified vs. not verified

- `extract-webpage-content.mjs` was tested against a local fixture
  mimicking vodacom.com's real structure (fetched and confirmed via a
  live check of vodacom.com's actual homepage) — two real bugs were
  caught and fixed this way (image+link blocks were being misclassified
  as plain link lists and silently dropping every image; a second heading
  within one content block was being dropped entirely). Both are fixed
  and re-verified.
- `push-sections-to-drupal.mjs` follows Drupal's documented JSON:API write
  format but has **not** been run against a live Drupal instance — there
  wasn't one reachable to test against. Run `--dry-run` first, read the
  output carefully, and test against a throwaway page before trusting it
  with real content.
