<?php

/**
 * DDEV local overrides for the newvodacomsite multisite.
 */

if (getenv('IS_DDEV_PROJECT') !== 'true') {
  return;
}

if (empty($settings['hash_salt'])) {
  $settings['hash_salt'] = 'ddev-newvodacomsite-local-hash-salt-change-me';
}

$databases['default']['default'] = [
  'database' => 'newvodacomsite',
  'username' => 'db',
  'password' => 'db',
  'host' => 'db',
  'port' => '3306',
  'driver' => 'mysql',
  'prefix' => '',
  'collation' => 'utf8mb4_general_ci',
];

// Keep local environment verbose for faster debugging during development.
$config['system.logging']['error_level'] = 'verbose';
