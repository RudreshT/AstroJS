#!/usr/bin/env node
/**
 * Pulls published content from Drupal's JSON:API (in every enabled
 * language) and writes it into src/content/** as flat JSON files that
 * Astro's content collections can read at build time.
 *
 * This is the ONLY point where the frontend talks to Drupal. It runs:
 *   - in CI, triggered by a Drupal webhook on publish/update
 *   - locally, when a developer runs `npm run sync-content`
 *
 * It never runs on a visitor's request — visitors only ever get the
 * static HTML this build produces, served from the CDN.
 *
 * IMPORTANT: the Paragraph → section mapping here must stay in sync with
 * drupal-modules/vodacom_preview/src/Controller/PreviewController.php's
 * normalizeParagraph() — that PHP version handles the same 10 Paragraph
 * types for DRAFT previews, this JS version handles them for the LIVE
 * published build. They read the same Drupal field names but through two
 * different APIs (JSON:API here vs. Drupal's Entity API there), so they
 * can't share code directly — but a new Paragraph type needs a case added
 * in BOTH places, or preview and the live site will disagree.
 */
import { writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';

const DRUPAL_BASE_URL = process.env.DRUPAL_BASE_URL || 'https://cms.vodacom.internal';
const LOCALES = ['en', 'fr', 'pt', 'sw', 'st'];

const ENTITY_MAP = {
  page: { jsonApiType: 'node--page', collection: 'page' },
  'media-release': { jsonApiType: 'node--media_release', collection: 'media-release' },
  'job-listing': { jsonApiType: 'node--job_listing', collection: 'job-listing' },
  'executive-profile': { jsonApiType: 'node--executive_profile', collection: 'executive-profile' },
};

// Every relationship path Page content might need resolved. JSON:API
// supports dot-path includes for nested relationships (paragraph inside a
// paragraph, media's underlying file, etc).
const PAGE_INCLUDES = [
  'field_hero_image',
  'field_hero_image.field_media_image',
  'field_hero_video',
  'field_sections',
  'field_sections.field_cards',
  'field_sections.field_cards.field_image',
  'field_sections.field_cards.field_image.field_media_image',
  'field_sections.field_items',
  'field_sections.field_steps',
  'field_sections.field_documents',
  'field_sections.field_documents.field_file',
  'field_sections.field_links',
].join(',');

async function fetchJsonApi(locale, jsonApiType, includes) {
  // Drupal's core content_translation + JSON:API modules expose translated
  // entities under a language-prefixed path, e.g. /fr/jsonapi/node/page
  const includeParam = includes ? `&include=${includes}` : '';
  const url = `${DRUPAL_BASE_URL}/${locale}/jsonapi/${jsonApiType.replace('--', '/')}?filter[status]=1${includeParam}`;
  const res = await fetch(url, { headers: { Accept: 'application/vnd.api+json' } });
  if (!res.ok) {
    throw new Error(`Drupal JSON:API request failed (${res.status}): ${url}`);
  }
  const json = await res.json();
  return { data: json.data ?? [], included: json.included ?? [] };
}

// --- JSON:API relationship-resolution helpers -----------------------------

function findIncluded(included, ref) {
  if (!ref) return null;
  return included.find((e) => e.type === ref.type && e.id === ref.id) ?? null;
}

/** Resolves a media-image relationship into {src, alt, width, height}. */
function resolveImage(resource, field, included) {
  const rel = resource.relationships?.[field]?.data;
  if (!rel) return undefined;
  const media = findIncluded(included, rel);
  if (!media) return undefined;
  const fileRel = media.relationships?.field_media_image;
  const file = findIncluded(included, fileRel?.data);
  if (!file) return undefined;
  const meta = fileRel.data?.meta ?? {};
  const rawUrl = file.attributes?.uri?.url ?? '';
  return {
    src: rawUrl.startsWith('http') ? rawUrl : `${DRUPAL_BASE_URL}${rawUrl}`,
    alt: meta.alt ?? '',
    width: meta.width ?? 0,
    height: meta.height ?? 0,
  };
}

/** Resolves a file relationship into a download URL + human-readable size. */
function resolveFile(resource, field, included) {
  const rel = resource.relationships?.[field]?.data;
  const file = findIncluded(included, rel);
  if (!file) return { href: '', fileSize: undefined };
  const rawUrl = file.attributes?.uri?.url ?? '';
  const bytes = file.attributes?.filesize ?? 0;
  const fileSize = bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)}MB` : `${Math.round(bytes / 1024)}KB`;
  return {
    href: rawUrl.startsWith('http') ? rawUrl : `${DRUPAL_BASE_URL}${rawUrl}`,
    fileSize: bytes ? fileSize : undefined,
  };
}

/**
 * Resolves a Drupal Link field. Simplification: only handles absolute
 * external URLs and Drupal-relative internal paths cleanly — an
 * `entity:node/123` style URI is passed through as-is, which will need a
 * real path resolved once actual content exists (Drupal's link field
 * doesn't include the target's URL alias in JSON:API by default).
 */
function resolveLink(resource, field) {
  const uri = resource.attributes?.[field]?.uri ?? '';
  if (uri.startsWith('http')) return uri;
  if (uri.startsWith('internal:/')) return uri.replace('internal:', '');
  return uri;
}

function getNestedParagraphs(resource, field, included) {
  const rel = resource.relationships?.[field]?.data;
  if (!rel) return [];
  const refs = Array.isArray(rel) ? rel : [rel];
  return refs.map((r) => findIncluded(included, r)).filter(Boolean);
}

/** Mirrors PreviewController::normalizeParagraph() — see file header note. */
function mapParagraphToSection(paragraph, included) {
  const type = paragraph.type.replace('paragraph--', '');
  const attrs = paragraph.attributes ?? {};

  switch (type) {
    case 'rich_text':
      return { type: 'richText', html: attrs.field_body?.processed ?? attrs.field_body ?? '' };

    case 'related_links_grid':
      return {
        type: 'relatedLinksGrid',
        heading: attrs.field_heading,
        cards: getNestedParagraphs(paragraph, 'field_cards', included).map((card) => ({
          image: resolveImage(card, 'field_image', included),
          label: card.attributes?.field_label ?? '',
          href: resolveLink(card, 'field_href'),
        })),
      };

    case 'expandable_card_grid':
      return {
        type: 'expandableCardGrid',
        heading: attrs.field_heading,
        columns: attrs.field_columns ?? 2,
        cards: getNestedParagraphs(paragraph, 'field_cards', included).map((card) => ({
          title: card.attributes?.field_title ?? '',
          subtitle: card.attributes?.field_subtitle,
          image: resolveImage(card, 'field_image', included),
          imageShape: card.attributes?.field_image_shape ?? 'square',
          body: card.attributes?.field_body?.processed ?? card.attributes?.field_body ?? '',
        })),
      };

    case 'accordion':
      return {
        type: 'accordion',
        items: getNestedParagraphs(paragraph, 'field_items', included).map((item) => ({
          icon: item.attributes?.field_icon,
          title: item.attributes?.field_title ?? '',
          teaser: item.attributes?.field_teaser ?? '',
          body: item.attributes?.field_body?.processed ?? item.attributes?.field_body ?? '',
        })),
      };

    case 'process_flow':
      return {
        type: 'processFlow',
        steps: getNestedParagraphs(paragraph, 'field_steps', included).map((step) => ({
          title: step.attributes?.field_title ?? '',
          description: step.attributes?.field_description,
        })),
      };

    case 'icon_link_grid':
      return {
        type: 'iconLinkGrid',
        heading: attrs.field_heading,
        items: getNestedParagraphs(paragraph, 'field_items', included).map((item) => ({
          icon: item.attributes?.field_icon ?? '',
          label: item.attributes?.field_label ?? '',
          href: resolveLink(item, 'field_href'),
          external: item.attributes?.field_external ?? false,
        })),
      };

    case 'callout_banner':
      return {
        type: 'calloutBanner',
        message: attrs.field_message,
        ctaLabel: attrs.field_cta_label,
        ctaHref: attrs.field_cta_href ? resolveLink(paragraph, 'field_cta_href') : undefined,
        tone: attrs.field_tone ?? 'red',
      };

    case 'document_download_list':
      return {
        type: 'documentDownloadList',
        heading: attrs.field_heading,
        documents: getNestedParagraphs(paragraph, 'field_documents', included).map((doc) => {
          const file = resolveFile(doc, 'field_file', included);
          return { label: doc.attributes?.field_label ?? '', href: file.href, fileSize: file.fileSize };
        }),
      };

    case 'related_link_list':
      return {
        type: 'relatedLinkList',
        links: getNestedParagraphs(paragraph, 'field_links', included).map((link) => ({
          label: link.attributes?.field_label ?? '',
          href: resolveLink(link, 'field_href'),
        })),
      };

    case 'share_price_widget':
      return { type: 'sharePriceWidget' };

    default:
      console.warn(`[sync-content] unknown paragraph type "${type}" — rendering as empty rich text`);
      return { type: 'richText', html: '' };
  }
}

function mapNodeToContent(node, locale, included) {
  const attrs = node.attributes;
  const sectionsRefs = getNestedParagraphs(node, 'field_sections', included);

  // Field-name mapping matches docs/CONTENT_MODEL.md. Kept intentionally
  // simple/explicit here rather than "clever" so non-Drupal devs can follow it.
  return {
    drupalId: node.id,
    lang: locale,
    title: attrs.title,
    slug: attrs.path?.alias?.replace(/^\//, '') ?? attrs.drupal_internal__nid?.toString(),
    heroHeadline: attrs.field_hero_headline ?? attrs.title,
    heroSubhead: attrs.field_hero_subhead ?? undefined,
    heroImage: resolveImage(node, 'field_hero_image', included),
    body: attrs.body?.processed ?? undefined,
    sections: sectionsRefs.length > 0 ? sectionsRefs.map((s) => mapParagraphToSection(s, included)) : undefined,
    seoTitle: attrs.field_seo_title ?? attrs.title,
    seoDescription: attrs.field_seo_description ?? undefined,
    updatedAt: attrs.changed,
  };
}

async function run() {
  for (const [collection, { jsonApiType }] of Object.entries(ENTITY_MAP)) {
    for (const locale of LOCALES) {
      const outDir = path.join('src', 'content', collection);
      await mkdir(outDir, { recursive: true });

      // Only Page content uses the full Paragraphs include chain — the
      // other content types don't have field_sections and a smaller
      // include list keeps their requests cheaper.
      const includes = collection === 'page' ? PAGE_INCLUDES : 'field_hero_image,field_hero_video,field_photo';

      let data = [];
      let included = [];
      try {
        ({ data, included } = await fetchJsonApi(locale, jsonApiType, includes));
      } catch (err) {
        console.warn(`[sync-content] skipping ${collection}/${locale}: ${err.message}`);
        continue;
      }

      for (const node of data) {
        const content = mapNodeToContent(node, locale, included);
        const outFile = path.join(outDir, `${locale}-${content.slug}.json`);
        await writeFile(outFile, JSON.stringify(content, null, 2));
      }
      console.log(`[sync-content] ${collection}/${locale}: ${data.length} entries`);
    }
  }
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
