#!/usr/bin/env node
/**
 * Stage 1 of the content import pipeline: fetch a real page (e.g. the
 * current vodacom.com homepage), extract its actual text/links/images into
 * a draft `sections` array matching src/content/config.ts's schema, and
 * write it to content-import/<slug>.json for a human to review and correct
 * BEFORE anything touches Drupal.
 *
 * This deliberately does NOT try to be fully automatic. Auto-classifying
 * arbitrary HTML into the "right" section type (richText vs
 * relatedLinksGrid vs relatedLinkList etc.) is a judgment call a script
 * gets wrong often enough that trusting it blindly would produce exactly
 * the "not ultra professional" result you're trying to avoid. Instead it:
 *   - strips legacy chrome (nav/header/footer/script/style) so you don't
 *     get old-site classes and layout cruft
 *   - groups content into blocks at each heading boundary
 *   - makes a best-guess `type` per block and flags LOW-CONFIDENCE guesses
 *     with a `reviewNote`, so you know exactly what to check by hand
 *
 * Usage:
 *   node scripts/extract-webpage-content.mjs https://vodacom.com/ home
 *
 * Output: content-import/home.json — open it, fix labels/grouping/section
 * types as needed, THEN run scripts/push-sections-to-drupal.mjs against it.
 */
import { writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import * as cheerio from 'cheerio';

const url = process.argv[2];
const slug = process.argv[3];

if (!url || !slug) {
  console.error('Usage: node scripts/extract-webpage-content.mjs <url> <output-slug>');
  process.exit(1);
}

function cleanText(str) {
  return (str || '').replace(/\s+/g, ' ').trim();
}

/** Strips everything except a small safe allowlist of inline tags, so
 * pasted content can't drag in the old site's classes/styles/divs. */
function cleanInlineHtml($, el) {
  const $el = $(el).clone();
  $el.find('script, style, iframe').remove();
  $el.find('*').each((_, node) => {
    const $node = $(node);
    // strip every attribute except href on <a> — no classes, no inline
    // styles, no data-* attributes from the source site survive.
    const attribs = { ...node.attribs };
    for (const attr of Object.keys(attribs)) {
      if (!(node.tagName === 'a' && attr === 'href')) {
        $node.removeAttr(attr);
      }
    }
  });
  return $el.html()?.trim() ?? '';
}

async function run() {
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (content-import-script)' } });
  if (!res.ok) {
    throw new Error(`Fetch failed (${res.status}): ${url}`);
  }
  const html = await res.text();
  const $ = cheerio.load(html);

  // Remove site chrome so only actual page content remains.
  $('nav, header, footer, script, style, noscript, .header-banner').remove();

  const title = cleanText($('title').first().text()) || slug;
  const main = $('main').length ? $('main') : $('body');

  const sections = [];
  let current = null;

  function flush() {
    if (!current) return;
    const paraCount = current.paragraphs.length;
    const linkCount = current.links.length;
    const imgCount = current.images.length;

    // Heuristic classification — deliberately conservative. Anything that
    // doesn't clearly match a pattern falls back to richText, which is
    // always visually safe even if not the "ideal" section type.
    // IMPORTANT: the image+link grid check MUST run before the plain
    // link-list check — a block with images AND links is a card grid, and
    // checking link-count first would silently drop every image.
    if (imgCount >= 2 && linkCount >= 2 && paraCount === 0) {
      sections.push({
        type: 'relatedLinksGrid',
        heading: current.heading,
        cards: current.images.slice(0, current.links.length).map((img, i) => ({
          image: img,
          label: current.links[i]?.label ?? '',
          href: current.links[i]?.href ?? '',
        })),
        reviewNote: 'Auto-detected as an image+link grid — verify each image is correctly paired with its link; pairing is positional and not guaranteed to match the source.',
      });
    } else if (linkCount >= 3 && paraCount === 0) {
      sections.push({
        type: 'relatedLinkList',
        links: current.links,
        reviewNote: `Auto-detected as a plain link list (${linkCount} links, no images or body text found in this block).`,
      });
    } else {
      const html = [
        current.heading ? `<h2>${current.heading}</h2>` : '',
        ...current.paragraphs,
      ].join('');
      sections.push({
        type: 'richText',
        html,
        reviewNote: paraCount === 0 ? 'No body text found under this heading — check the source page manually, something may not have been captured.' : undefined,
      });
    }
    current = null;
  }

  main.children().each((_, el) => {
    const $el = $(el);
    const heading = $el.find('h1, h2, h3').first();

    if (heading.length && $el.is(heading.parent()) === false) {
      // heading found nested inside a wrapper div — treat the whole
      // wrapper as one block starting a new section.
    }

    // Start a new block on any direct heading-bearing element.
    if ($el.is('h1, h2, h3') || heading.length) {
      flush();
      current = {
        heading: cleanText(heading.length ? heading.text() : $el.text()),
        paragraphs: [],
        links: [],
        images: [],
      };
    }
    if (!current) {
      current = { heading: '', paragraphs: [], links: [], images: [] };
    }

    $el.find('p, h2, h3, h4').each((_, node) => {
      // Skip the element already used as this block's title, whichever
      // tag it was — everything else (including a SECOND heading in the
      // same wrapper, e.g. an h1 title followed by an h2 subhead) is kept
      // as inline content instead of being silently dropped, which was
      // the original bug here.
      if (node === heading.get(0)) return;
      if (node.tagName === 'p') {
        const html = cleanInlineHtml($, node);
        if (html) current.paragraphs.push(`<p>${html}</p>`);
      } else {
        const text = cleanText($(node).text());
        if (text) current.paragraphs.push(`<h3>${text}</h3>`);
      }
    });
    $el.find('a[href]').each((_, a) => {
      const label = cleanText($(a).text());
      const href = $(a).attr('href');
      if (label && href && !href.startsWith('#')) {
        current.links.push({ label, href });
      }
    });
    $el.find('img[src]').each((_, img) => {
      const src = $(img).attr('src');
      const alt = $(img).attr('alt') || '';
      if (src) current.images.push({ src, alt, width: 1200, height: 675 });
    });
  });
  flush();

  const draft = {
    _instructions: 'REVIEW EVERY SECTION BELOW before running push-sections-to-drupal.mjs. Fix mis-classified types, remove noise sections, rewrite awkward auto-extracted text — this file is a starting draft, not finished content.',
    sourceUrl: url,
    slug,
    title,
    sections,
  };

  await mkdir('content-import', { recursive: true });
  const outPath = path.join('content-import', `${slug}.json`);
  await writeFile(outPath, JSON.stringify(draft, null, 2));

  console.log(`Extracted ${sections.length} section(s) from ${url}`);
  console.log(`Written to ${outPath} — review it before importing.`);
  const flagged = sections.filter((s) => s.reviewNote);
  if (flagged.length) {
    console.log(`\n${flagged.length} section(s) flagged for review:`);
    flagged.forEach((s, i) => console.log(`  - [${s.type}] ${s.reviewNote}`));
  }
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
