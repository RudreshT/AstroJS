#!/usr/bin/env node
/**
 * Pulls published content from Drupal's JSON:API (in every enabled
 * language) and writes it into src/content/** as flat JSON files that
 * Astro's content collections can read at build time.
 *
 * This is the ONLY point where the frontend talks to Drupal. It runs:
 *   - in CI, triggered by a Drupal webhook on publish/update
 *   - locally, when a developer runs `npm run sync-content`
 *
 * It never runs on a visitor's request — visitors only ever get the
 * static HTML this build produces, served from the CDN.
 *
 * IMPORTANT: the Paragraph → section mapping here must stay in sync with
 * drupal-modules/vodacom_preview/src/Controller/PreviewController.php's
 * normalizeParagraph() — that PHP version handles the same 10 Paragraph
 * types for DRAFT previews, this JS version handles them for the LIVE
 * published build. They read the same Drupal field names but through two
 * different APIs (JSON:API here vs. Drupal's Entity API there), so they
 * can't share code directly — but a new Paragraph type needs a case added
 * in BOTH places, or preview and the live site will disagree.
 */
import { writeFile, mkdir, readdir, unlink } from 'node:fs/promises';
import path from 'node:path';

const DRUPAL_BASE_URL = process.env.DRUPAL_BASE_URL || 'https://cms.vodacom.internal';
const DRUPAL_STATUS_FILTER = (process.env.DRUPAL_STATUS_FILTER || '1').trim();
const LOCALES = (process.env.DRUPAL_LOCALES || 'en,fr,pt,sw,st')
  .split(',')
  .map((v) => v.trim())
  .filter(Boolean);
const ALLOW_INSECURE_TLS = ['1', 'true', 'yes'].includes(String(process.env.DRUPAL_ALLOW_INSECURE_TLS || '').toLowerCase());
if (ALLOW_INSECURE_TLS) {
  // Local DDEV cert helper. Do not use in production environments.
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
}

const ENTITY_MAP = {
  page: { jsonApiTypes: ['node--page', 'node--basic_page'], collection: 'page' },
  'media-release': { jsonApiTypes: ['node--media_release', 'node--article'], collection: 'media-release' },
  'job-listing': { jsonApiTypes: ['node--job_listing'], collection: 'job-listing' },
  'executive-profile': { jsonApiTypes: ['node--executive_profile'], collection: 'executive-profile' },
  // These two were missing from this map — meaning Board of Directors and
  // Calendar would silently sync zero entries no matter what existed in
  // Drupal. Re-added here, following the same jsonApiTypes-fallback
  // pattern as the others above.
  'board-member': { jsonApiTypes: ['node--board_member'], collection: 'board-member' },
  'investor-event': { jsonApiTypes: ['node--investor_event', 'node--calendar_event'], collection: 'investor-event' },
  'contact-department': { jsonApiTypes: ['node--contact_department'], collection: 'contact-department' },
};

// Every relationship path Page content might need resolved. JSON:API
// supports dot-path includes for nested relationships (paragraph inside a
// paragraph, media's underlying file, etc).
const PAGE_INCLUDES = [
  // Keep include paths conservative so they remain valid across different
  // paragraph bundle schemas. Deep include chains can 400 when one bundle
  // doesn't expose that relationship, which would otherwise drop ALL includes.
  'field_hero_image',
  'field_hero_image.field_media_image',
  'field_hero_video',
  'field_sections',
].join(',');

async function fetchJsonApi(locale, jsonApiType, includes) {
  // Drupal's core content_translation + JSON:API modules expose translated
  // entities under a language-prefixed path, e.g. /fr/jsonapi/node/page
  const endpoint = `jsonapi/${jsonApiType.replace('--', '/')}`;
  const statusQuery = DRUPAL_STATUS_FILTER.toLowerCase() === 'all'
    ? ''
    : `filter[status]=${encodeURIComponent(DRUPAL_STATUS_FILTER)}`;
  const buildQuery = (includeValue) => {
    const parts = [];
    if (statusQuery) parts.push(statusQuery);
    if (includeValue) parts.push(`include=${includeValue}`);
    return parts.length > 0 ? `?${parts.join('&')}` : '';
  };
  const queryVariants = includes ? [buildQuery(includes), buildQuery('')] : [buildQuery('')];

  let lastError;
  for (const query of queryVariants) {
    // Try language-prefixed and non-prefixed endpoints so this works in both
    // multilingual and single-language Drupal setups.
    const candidates = locale === 'en'
      ? [
          `${DRUPAL_BASE_URL}/${endpoint}${query}`,
          `${DRUPAL_BASE_URL}/${locale}/${endpoint}${query}`,
        ]
      : [
          `${DRUPAL_BASE_URL}/${locale}/${endpoint}${query}`,
          `${DRUPAL_BASE_URL}/${endpoint}${query}`,
        ];

    for (const url of candidates) {
      const res = await fetch(url, {
        headers: { Accept: 'application/vnd.api+json' },
      });

      if (res.ok) {
        const json = await res.json();
        return { data: json.data ?? [], included: json.included ?? [] };
      }

      if (res.status !== 404) {
        lastError = new Error(`Drupal JSON:API request failed (${res.status}): ${url}`);
        break;
      }

      lastError = new Error(`Drupal JSON:API endpoint not found (${res.status}): ${url}`);
    }

    // If includes caused a bad request, retry the same type without include.
    if (lastError && /request failed \(400\)/.test(lastError.message)) {
      continue;
    }
  }

  throw lastError;
}

async function fetchParagraphByRef(locale, ref) {
  if (!ref?.type || !ref?.id) return { data: null, included: [] };

  const endpoint = `jsonapi/${ref.type.replace('--', '/')}/${ref.id}`;
  const includeChain = [
    'field_cards',
    'field_items',
    'field_steps',
    'field_documents',
    'field_image',
    'field_file',
    'field_links',
    'field_href',
    'field_link',
    'field_media_image',
  ].join(',');
  const queryVariants = [`?include=${includeChain}`, ''];

  let lastError;
  for (const query of queryVariants) {
    const candidates = locale === 'en'
      ? [
          `${DRUPAL_BASE_URL}/${endpoint}${query}`,
          `${DRUPAL_BASE_URL}/${locale}/${endpoint}${query}`,
        ]
      : [
          `${DRUPAL_BASE_URL}/${locale}/${endpoint}${query}`,
          `${DRUPAL_BASE_URL}/${endpoint}${query}`,
        ];

    for (const url of candidates) {
      const res = await fetch(url, {
        headers: { Accept: 'application/vnd.api+json' },
      });

      if (res.ok) {
        const json = await res.json();
        return { data: json.data ?? null, included: json.included ?? [] };
      }

      if (res.status === 404) {
        lastError = new Error(`Drupal JSON:API paragraph not found (${res.status}): ${url}`);
        continue;
      }

      if (res.status === 400 && query) {
        // Retry same endpoint without include chain if this bundle rejects it.
        lastError = new Error(`Drupal JSON:API paragraph include failed (${res.status}): ${url}`);
        break;
      }

      lastError = new Error(`Drupal JSON:API paragraph request failed (${res.status}): ${url}`);
      break;
    }

    if (lastError && /include failed \(400\)/.test(lastError.message)) {
      continue;
    }
  }

  console.warn(`[sync-content] paragraph fetch failed for ${ref.type}:${ref.id} (${lastError?.message ?? 'unknown error'})`);
  return { data: null, included: [] };
}

// --- JSON:API relationship-resolution helpers -----------------------------

function findIncluded(included, ref) {
  if (!ref) return null;
  return included.find((e) => e.type === ref.type && e.id === ref.id) ?? null;
}

/** Resolves a media-image relationship into {src, alt, width, height}. */
function resolveImage(resource, field, included) {
  const rel = resource.relationships?.[field]?.data;
  if (!rel) return undefined;
  const media = findIncluded(included, rel);
  if (!media) return undefined;
  const fileRel = media.relationships?.field_media_image;
  const file = findIncluded(included, fileRel?.data);
  if (!file) return undefined;
  const meta = fileRel.data?.meta ?? {};
  const rawUrl = file.attributes?.uri?.url ?? '';
  return {
    src: rawUrl.startsWith('http') ? rawUrl : `${DRUPAL_BASE_URL}${rawUrl}`,
    alt: meta.alt ?? '',
    width: meta.width ?? 0,
    height: meta.height ?? 0,
  };
}

/** Resolves a file relationship into a download URL + human-readable size. */
function resolveFile(resource, field, included) {
  const rel = resource.relationships?.[field]?.data;
  const file = findIncluded(included, rel);
  if (!file) return { href: '', fileSize: undefined };
  const rawUrl = file.attributes?.uri?.url ?? '';
  const bytes = file.attributes?.filesize ?? 0;
  const fileSize = bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)}MB` : `${Math.round(bytes / 1024)}KB`;
  return {
    href: rawUrl.startsWith('http') ? rawUrl : `${DRUPAL_BASE_URL}${rawUrl}`,
    fileSize: bytes ? fileSize : undefined,
  };
}

/**
 * Resolves a Drupal Link field. Simplification: only handles absolute
 * external URLs and Drupal-relative internal paths cleanly — an
 * `entity:node/123` style URI is passed through as-is, which will need a
 * real path resolved once actual content exists (Drupal's link field
 * doesn't include the target's URL alias in JSON:API by default).
 */
function resolveLink(resource, field) {
  const uri = resource.attributes?.[field]?.uri ?? '';
  if (uri.startsWith('http')) return uri;
  if (uri.startsWith('internal:/')) return uri.replace('internal:', '');
  return uri;
}

function getNestedParagraphs(resource, field, included) {
  const rel = resource.relationships?.[field]?.data;
  if (!rel) return [];
  const refs = Array.isArray(rel) ? rel : [rel];
  return refs.map((r) => findIncluded(included, r)).filter(Boolean);
}

function parseDelimitedLinks(rawValue) {
  const toEntries = (text) => String(text || '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [label, href] = line.split('|').map((v) => v?.trim());
      return { label: label || href || '', href: href || '#' };
    });

  if (typeof rawValue === 'string') {
    return toEntries(rawValue);
  }

  if (Array.isArray(rawValue)) {
    return rawValue.flatMap((item) => {
      if (typeof item === 'string') return toEntries(item);
      if (item && typeof item.value === 'string') return toEntries(item.value);
      return [];
    });
  }

  if (rawValue && typeof rawValue.value === 'string') {
    return toEntries(rawValue.value);
  }

  return [];
}

function createPlaceholderImage(label) {
  const safeLabel = String(label || 'Vodacom update');
  return {
    src: '',
    alt: `${safeLabel} placeholder image`,
    width: 1200,
    height: 675,
  };
}

/** Mirrors PreviewController::normalizeParagraph() — see file header note. */
function mapParagraphToSection(paragraph, included) {
  const type = paragraph.type.replace('paragraph--', '');
  const attrs = paragraph.attributes ?? {};

  switch (type) {
    case 'rich_text':
      return { type: 'richText', html: attrs.field_body?.processed ?? attrs.field_body ?? '' };

    case 'related_links_grid':
      // Supports both schemas:
      // 1) nested cards via field_cards relationship
      // 2) single direct card fields on the paragraph itself
      //    (field_image, field_label, field_link)
      {
        const nestedCards = getNestedParagraphs(paragraph, 'field_cards', included).map((card) => ({
          label: card.attributes?.field_label ?? '',
          image: resolveImage(card, 'field_image', included) ?? createPlaceholderImage(card.attributes?.field_label ?? ''),
          href: resolveLink(card, 'field_href'),
        }));

        const directCard = attrs.field_label || attrs.field_link || paragraph.relationships?.field_image
          ? [{
              label: attrs.field_label ?? '',
              image: resolveImage(paragraph, 'field_image', included) ?? createPlaceholderImage(attrs.field_label ?? ''),
              href: resolveLink(paragraph, 'field_link') || resolveLink(paragraph, 'field_href'),
            }]
          : [];

        return {
          type: 'relatedLinksGrid',
          heading: attrs.field_heading,
          cards: nestedCards.length > 0 ? nestedCards : directCard,
        };
      }

    case 'expandable_card_grid':
      return {
        type: 'expandableCardGrid',
        heading: attrs.field_heading,
        columns: attrs.field_columns ?? 2,
        cards: getNestedParagraphs(paragraph, 'field_cards', included).map((card) => ({
          title: card.attributes?.field_title ?? '',
          subtitle: card.attributes?.field_subtitle,
          image: resolveImage(card, 'field_image', included),
          imageShape: card.attributes?.field_image_shape ?? 'square',
          body: card.attributes?.field_body?.processed ?? card.attributes?.field_body ?? '',
        })),
      };

    case 'accordion':
      return {
        type: 'accordion',
        items: getNestedParagraphs(paragraph, 'field_items', included).map((item) => ({
          icon: item.attributes?.field_icon,
          title: item.attributes?.field_title ?? '',
          teaser: item.attributes?.field_teaser ?? '',
          body: item.attributes?.field_body?.processed ?? item.attributes?.field_body ?? '',
        })),
      };

    case 'process_flow':
      return {
        type: 'processFlow',
        steps: getNestedParagraphs(paragraph, 'field_steps', included).map((step) => ({
          title: step.attributes?.field_title ?? '',
          description: step.attributes?.field_description,
        })),
      };

    case 'icon_link_grid':
      return {
        type: 'iconLinkGrid',
        heading: attrs.field_heading,
        items: getNestedParagraphs(paragraph, 'field_items', included).map((item) => ({
          icon: item.attributes?.field_icon ?? '',
          label: item.attributes?.field_label ?? '',
          href: resolveLink(item, 'field_href'),
          external: item.attributes?.field_external ?? false,
        })),
      };

    case 'callout_banner':
      return {
        type: 'calloutBanner',
        message: attrs.field_message,
        ctaLabel: attrs.field_cta_label,
        ctaHref: attrs.field_cta_href
          ? resolveLink(paragraph, 'field_cta_href')
          : attrs.field_cta_link
            ? resolveLink(paragraph, 'field_cta_link')
            : undefined,
        tone: attrs.field_tone ?? 'red',
      };

    case 'document_download_list':
      return {
        type: 'documentDownloadList',
        heading: attrs.field_heading,
        documents: getNestedParagraphs(paragraph, 'field_documents', included).map((doc) => {
          const file = resolveFile(doc, 'field_file', included);
          return { label: doc.attributes?.field_label ?? '', href: file.href, fileSize: file.fileSize };
        }),
      };

    case 'related_link_list':
      {
        const nestedLinks = getNestedParagraphs(paragraph, 'field_links', included).map((link) => ({
          label: link.attributes?.field_label ?? '',
          href: resolveLink(link, 'field_href') || resolveLink(link, 'field_link'),
        }));

        // Fallback for schema where field_links is long text. Format:
        // Label|/path per line.
        const directLinks = parseDelimitedLinks(attrs.field_links);

        return {
          type: 'relatedLinkList',
          links: nestedLinks.length > 0 ? nestedLinks : directLinks,
        };
      }

    case 'share_price_widget':
      return { type: 'sharePriceWidget' };

    default:
      console.warn(`[sync-content] unknown paragraph type "${type}" — rendering as empty rich text`);
      return { type: 'richText', html: '' };
  }
}

async function mapNodeToContent(node, locale, included) {
  const attrs = node.attributes;
  const sectionRefsRaw = node.relationships?.field_sections?.data;
  const sectionRefs = Array.isArray(sectionRefsRaw)
    ? sectionRefsRaw
    : sectionRefsRaw
      ? [sectionRefsRaw]
      : [];
  const sections = sectionRefs.length > 0
    ? (await Promise.all(sectionRefs.map(async (ref) => {
        const fromIncluded = findIncluded(included, ref);
        if (fromIncluded) {
          return mapParagraphToSection(fromIncluded, included);
        }

        const fetched = await fetchParagraphByRef(locale, ref);
        if (!fetched.data) return null;

        // Merge top-level includes with paragraph-scoped includes so nested
        // relationships (files/media/items) can still resolve.
        return mapParagraphToSection(fetched.data, [...included, ...fetched.included]);
      }))).filter(Boolean)
    : [];
  const fallbackSlug = (attrs.title || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || attrs.drupal_internal__nid?.toString();
  const alias = attrs.path?.alias?.replace(/^\//, '').replace(/\/$/, '');
  const normalizedSlug = alias === '' ? 'home' : alias;

  // Field-name mapping matches docs/CONTENT_MODEL.md. Kept intentionally
  // simple/explicit here rather than "clever" so non-Drupal devs can follow it.
  return {
    drupalId: node.id,
    lang: locale,
    title: attrs.title,
    slug: normalizedSlug || fallbackSlug,
    heroHeadline: attrs.field_hero_headline ?? attrs.title,
    heroSubhead: attrs.field_hero_subhead ?? undefined,
    heroImage: resolveImage(node, 'field_hero_image', included),
    body: attrs.body?.processed ?? undefined,
    sections: sections.length > 0 ? sections : undefined,
    seoTitle: attrs.field_seo_title ?? attrs.title,
    seoDescription: attrs.field_seo_description ?? undefined,
    updatedAt: attrs.changed,
  };
}

function mapMediaReleaseNodeToContent(node, locale) {
  const attrs = node.attributes ?? {};
  const body = attrs.body?.processed ?? attrs.body?.value ?? '';
  const fallbackSlug = (attrs.title || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || attrs.drupal_internal__nid?.toString();

  return {
    drupalId: node.id,
    lang: locale,
    title: attrs.title ?? 'Untitled',
    slug: attrs.path?.alias?.replace(/^\//, '') ?? fallbackSlug,
    publishedAt: attrs.created ?? attrs.changed,
    intro: attrs.body?.summary ?? (body.replace(/<[^>]*>/g, '').slice(0, 180) || attrs.title || ''),
    body,
    category: 'general',
    featured: false,
  };
}

/**
 * These five mappers exist because the generic mapNodeToContent() shape
 * (title/heroHeadline/body/sections — built for the `page` content type)
 * doesn't match board-member, investor-event, contact-department,
 * job-listing, or executive-profile's schemas in src/content/config.ts at
 * all. Before this fix, all five were silently routed through the generic
 * mapper in run() below, which would fail Zod validation the moment real
 * data existed for any of them (missing required fields like `name`,
 * `role`, `photo`, `bio`, `eventStart`, etc.) — a build-breaking bug that
 * simply hadn't been hit yet because these types hadn't been synced with
 * real content.
 */

function mapBoardMemberNodeToContent(node, locale, included) {
  const attrs = node.attributes ?? {};
  return {
    drupalId: node.id,
    lang: locale,
    name: attrs.title ?? 'Untitled',
    age: attrs.field_age ?? undefined,
    role: attrs.field_role ?? '',
    qualifications: attrs.field_qualifications ?? undefined,
    committees: attrs.field_committees ?? [],
    photo: resolveImage(node, 'field_photo', included) ?? { src: '', alt: attrs.title ?? '', width: 0, height: 0 },
    bio: attrs.body?.processed ?? attrs.body?.value ?? '',
    order: attrs.field_order ?? 0,
  };
}

function mapInvestorEventNodeToContent(node, locale) {
  const attrs = node.attributes ?? {};
  return {
    drupalId: node.id,
    lang: locale,
    title: attrs.title ?? 'Untitled event',
    eventStart: attrs.field_event_start ?? attrs.created,
    eventEnd: attrs.field_event_end ?? undefined,
    location: attrs.field_location || 'Online',
    time: attrs.field_time ?? undefined,
  };
}

function mapContactDepartmentNodeToContent(node, locale) {
  const attrs = node.attributes ?? {};
  return {
    drupalId: node.id,
    lang: locale,
    departmentId: attrs.field_department_id ?? 'consumer',
    label: attrs.field_label ?? attrs.title ?? '',
    heading: attrs.field_heading ?? attrs.title ?? '',
    body: attrs.body?.processed ?? attrs.body?.value ?? '',
    order: attrs.field_order ?? 0,
  };
}

function mapJobListingNodeToContent(node, locale) {
  const attrs = node.attributes ?? {};
  const fallbackSlug = (attrs.title || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || attrs.drupal_internal__nid?.toString();
  return {
    drupalId: node.id,
    lang: locale,
    title: attrs.title ?? 'Untitled role',
    slug: attrs.path?.alias?.replace(/^\//, '') ?? fallbackSlug,
    location: attrs.field_location ?? '',
    department: attrs.field_department ?? '',
    closingDate: attrs.field_closing_date ?? undefined,
    applyUrl: attrs.field_apply_url?.uri ?? attrs.field_apply_url ?? '',
    body: attrs.body?.processed ?? attrs.body?.value ?? '',
  };
}

function mapExecutiveProfileNodeToContent(node, locale, included) {
  const attrs = node.attributes ?? {};
  return {
    drupalId: node.id,
    lang: locale,
    name: attrs.title ?? 'Untitled',
    role: attrs.field_role ?? '',
    photo: resolveImage(node, 'field_photo', included) ?? { src: '', alt: attrs.title ?? '', width: 0, height: 0 },
    bio: attrs.body?.processed ?? attrs.body?.value ?? '',
    order: attrs.field_order ?? 0,
  };
}

/** Dispatches to the correct mapper for a given collection — see the
 * comment above the five mapper functions for why this dispatch exists. */
async function mapNodeForCollection(collection, node, locale, included) {
  switch (collection) {
    case 'media-release': return mapMediaReleaseNodeToContent(node, locale);
    case 'board-member': return mapBoardMemberNodeToContent(node, locale, included);
    case 'investor-event': return mapInvestorEventNodeToContent(node, locale);
    case 'contact-department': return mapContactDepartmentNodeToContent(node, locale);
    case 'job-listing': return mapJobListingNodeToContent(node, locale);
    case 'executive-profile': return mapExecutiveProfileNodeToContent(node, locale, included);
    case 'page':
    default:
      return mapNodeToContent(node, locale, included);
  }
}

async function run() {
  for (const [collection, { jsonApiTypes }] of Object.entries(ENTITY_MAP)) {
    for (const locale of LOCALES) {
      const outDir = path.join('src', 'content', collection);
      await mkdir(outDir, { recursive: true });

      // Remove stale entries for this locale before re-syncing so renamed
      // slugs or previous schema variants do not linger.
      const existing = await readdir(outDir);
      await Promise.all(
        existing
          .filter((name) => name.startsWith(`${locale}-`) && name.endsWith('.json'))
          .map((name) => unlink(path.join(outDir, name)))
      );

      // Only Page content uses the full Paragraphs include chain — the
      // other content types don't have field_sections and a smaller
      // include list keeps their requests cheaper.
      // NOTE: field_photo.field_media_image (and the equivalent for
      // field_hero_image) must be included as a nested relationship, or
      // resolveImage() finds the media entity but not the underlying file
      // it points at — meaning src/alt/width/height silently resolve to
      // nothing even when an editor has attached a real photo.
      const includes = collection === 'page'
        ? PAGE_INCLUDES
        : 'field_hero_image,field_hero_image.field_media_image,field_hero_video,field_photo,field_photo.field_media_image';

      let data = [];
      let included = [];
      let lastError;
      for (const jsonApiType of jsonApiTypes) {
        try {
          ({ data, included } = await fetchJsonApi(locale, jsonApiType, includes));
          lastError = undefined;
          break;
        } catch (err) {
          lastError = err;
        }
      }

      if (lastError) {
        console.warn(`[sync-content] skipping ${collection}/${locale}: ${lastError.message}`);
        continue;
      }

      for (const node of data) {
        const content = await mapNodeForCollection(collection, node, locale, included);
        const outFile = path.join(outDir, `${locale}-${content.slug}.json`);
        await writeFile(outFile, JSON.stringify(content, null, 2));
      }
      console.log(`[sync-content] ${collection}/${locale}: ${data.length} entries`);
    }
  }
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
