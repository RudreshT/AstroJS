// Single source of truth for site structure. Built from the legacy
// site-map.php inventory. Reused by the /site-map page, and a good
// candidate to also drive the mega-menu in Nav.astro once that's built out.
export interface SiteLink { label: string; href: string; children?: SiteLink[] }
export interface SiteSection { heading: string; href?: string; links: SiteLink[] }

export const siteStructure: SiteSection[] = [
  { heading: 'Home page', href: '/' , links: [] },
  {
    heading: 'About us',
    links: [
      { label: 'Overview', href: '/about-us' },
      { label: 'Where we operate', href: '/where-we-operate' },
      { label: 'Board of directors', href: '/board-of-directors' },
      { label: 'Executive committee', href: '/executive-committee' },
      { label: 'Senior leadership', href: '/senior-leadership' },
      { label: 'Governance', href: '/governance' },
      {
        label: 'Privacy centre', href: '/privacy-centre',
        children: [
          { label: "Vodacom's approach to privacy and security", href: '/vodacoms-approach-to-privacy-and-security' },
          { label: 'Privacy Policy', href: '/vodacom-privacy-policy' },
          { label: 'Candidate Privacy Statement', href: '/vodacom-candidate-privacy-statement' },
          { label: 'Contact us', href: '/privacy-centre-contact-us' },
        ],
      },
      { label: 'Vodacom Foundation', href: '/vodacom-foundation' },
    ],
  },
  {
    heading: 'What we do',
    links: [
      { label: 'Overview', href: '/what-we-do' },
      { label: 'Our strategy', href: '/our-strategy' },
      { label: 'Technology', href: '/technology' },
      { label: 'Consumers', href: '/consumers' },
      {
        label: 'Vodacom Business', href: '/vodacom-business',
        children: [
          { label: 'Vodacom Business Africa', href: '/vodacom-business-africa' },
          { label: 'Carrier services', href: '/carrier-services' },
        ],
      },
      { label: 'Financial services', href: '/financial-services' },
      {
        label: 'Public policy', href: '/public-policy',
        children: [
          { label: 'Africa.Connected', href: '/africa-connected' },
          { label: 'Public Policy Reports', href: '/public-policy-reports' },
        ],
      },
    ],
  },
  {
    heading: 'Our purpose',
    links: [
      { label: 'Overview', href: '/our-purpose' },
      { label: 'Digital society', href: '/digital-society' },
      { label: 'Inclusion for all', href: '/inclusion-for-all' },
      { label: 'Planet', href: '/planet' },
      {
        label: 'Operating responsibly', href: '/operating-responsibly',
        children: [
          { label: 'Black Economic Empowerment', href: '/black-economic-empowerment' },
          { label: 'Responsible supply chain', href: '/responsible-supply-chain' },
          { label: 'Mobiles, masts and health', href: '/mobiles-masts-and-health' },
        ],
      },
      { label: 'SDGs', href: '/sdgs' },
      { label: 'Reporting centre', href: '/reporting-centre' },
    ],
  },
  {
    heading: 'Investor relations',
    links: [
      { label: 'Overview', href: '/investor-relations' },
      {
        label: 'Financial results', href: '/financial-results',
        children: [
          { label: 'Annual results', href: '/annual-results' },
          { label: 'Interim results', href: '/interim-results' },
          { label: 'Quarterly results', href: '/quarterly-results' },
          { label: 'Presentations', href: '/presentations' },
        ],
      },
      { label: 'Integrated Annual Reports', href: '/integrated-reports' },
      {
        label: 'Stock information', href: '/stock-information',
        children: [
          { label: 'Share price', href: '/share-price' },
          { label: 'Share price and SENS', href: '/share-price-and-sens' },
          { label: 'Dividends', href: '/dividends' },
          { label: 'Analyst coverage & consensus', href: '/analyst-coverage' },
          { label: 'Shareholder meetings', href: '/shareholder-meetings' },
          { label: "FAQ's", href: '/faqs' },
        ],
      },
      { label: 'Calendar', href: '/calendar' },
      { label: 'Contacts', href: '/contacts' },
    ],
  },
  {
    heading: 'Media',
    links: [
      { label: 'Overview', href: '/media' },
      { label: 'Media releases', href: '/media-releases' },
      { label: 'Register for media', href: '/register-for-media' },
      { label: 'Media resources', href: '/media-resources' },
    ],
  },
  {
    heading: 'Careers',
    links: [
      { label: 'Overview', href: '/careers' },
      { label: 'Life at Vodacom', href: '/life-at-vodacom' },
      { label: 'Where do I fit in?', href: '/where-do-i-fit-in' },
      { label: 'Search jobs', href: '/search-jobs' },
      { label: 'Application process', href: '/application-process' },
      { label: 'Alumni network programme', href: '/alumni-network-programme' },
    ],
  },
  { heading: 'Contact us', href: '/contact-us', links: [] },
];
