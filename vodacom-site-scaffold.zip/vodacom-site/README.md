# Vodacom site — decoupled Drupal + Astro

A multilingual, performance-first rebuild: **Drupal** as the content
backend (so non-technical editors keep a familiar CMS), **Astro** as the
frontend (static output, near-zero JS, deployed to a CDN) — targeting
LCP < 1.5s / fully interactive < 2s on mobile.

## Read these in order

1. [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — how the pieces fit together and why this hits the speed target
2. [`docs/DEVELOPER_SETUP.md`](docs/DEVELOPER_SETUP.md) — **start here for setup** — the full from-scratch walkthrough, Drupal + Astro + preview + deploy
3. [`docs/CONTENT_MODEL.md`](docs/CONTENT_MODEL.md) — Drupal content types/fields, plus the Paragraphs/section catalog
4. [`docs/PERFORMANCE_BUDGET.md`](docs/PERFORMANCE_BUDGET.md) — concrete numeric targets and the pre-launch checklist
5. [`docs/CONTACT_FORM.md`](docs/CONTACT_FORM.md) — the contact form's backend contract
6. [`docs/EDITOR_GUIDE.md`](docs/EDITOR_GUIDE.md) — for the non-technical content team, no code involved

## Repo layout

```
astro.config.mjs          # locales list, static output config
tailwind.config.mjs       # brand colors/fonts, compiled at build time
src/
  templates/               # actual page markup (one per page type)
  pages/
    *.astro                 # thin English wrappers (root, no locale prefix)
    [lang]/*.astro           # thin wrappers for fr/pt/sw/st, via getStaticPaths
  layouts/BaseLayout.astro
  components/              # Nav, Carousel, Footer, DirectorCard, EventCard,
                            # ContactForm/ContactTabs, SharePriceWidget, etc.
  content/config.ts         # typed schema mirroring Drupal's JSON:API shape
  content/*/                # synced content JSON (sample entries included)
  data/siteStructure.ts     # full page/route inventory, from site-map.php
  i18n/ui.ts                # UI chrome translations (nav, buttons, footer)
scripts/
  fetch-drupal-content.mjs # pulls published content from Drupal at build time
docs/                      # architecture, content model, performance, editor guide, contact form
```

### Why pages are split into `templates/` + thin wrappers

Astro doesn't support an optional-bracket directory like `src/pages/[[lang]]/`
(an earlier version of this scaffold tried that and it broke the build).
Since English has no URL prefix but every other locale does
(`/fr/...`, `/pt/...`), each page's real markup lives once in
`src/templates/`, and two thin wrapper files render it: one at the site
root (English) and one under `[lang]/` (everything else, via
`getStaticPaths`). Add a new page by creating one template + two ~5-line
wrappers, following any existing page as a pattern.

## This has been build-tested

`npm install && npm run build` runs clean (exit 0) as of this scaffold,
producing 40 static pages (8 page types × 5 locales) at under 1MB total
dist size, using placeholder imagery. Content collections ship with one
sample entry each so pages render real content immediately, before Drupal
is even connected — replace/delete the sample JSON files in
`src/content/*/` once `npm run sync-content` is wired up to a live Drupal.

## Getting started (developers)

See `docs/DEVELOPER_SETUP.md` for the full walkthrough. Quick version:

```bash
npm install
export DRUPAL_BASE_URL=https://cms.vodacom.internal
export PREVIEW_SECRET=some-random-string
npm run sync-content
npm run dev
```

## What's a starting scaffold vs. what's left to do

This repo covers 8 page types (home, about us, board of directors, careers,
contact us, calendar, privacy policy, site map) across 5 languages, with a
tested build, sample content, and the Drupal↔Astro content contract. Still
needed before launch:

- Build out remaining page templates (executive committee, investor
  relations, media releases index, individual news articles, job search)
  following the pattern in `src/templates/` + the two thin page wrappers
- Stand up the actual Drupal instance with the content types in
  `CONTENT_MODEL.md`, and the publish webhook described in `ARCHITECTURE.md`
- Replace placeholder imagery with real optimized assets, and re-encode
  any video per the checklist in `PERFORMANCE_BUDGET.md`
- Build the `/api/contact` endpoint per `docs/CONTACT_FORM.md`
- Wire up CI (build + Lighthouse budget check + deploy to CDN)
- Regenerate a sitemap.xml from `src/data/siteStructure.ts` (the
  `@astrojs/sitemap` integration was removed — see the note in
  `astro.config.mjs` for why)
- Complete translations for the initial 5 languages beyond English

Happy to build out any of these next — just say which piece.
