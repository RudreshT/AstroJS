# Guide for content editors (no technical background needed)

You never need to touch code, GitHub, or anything in this repository. Your
whole job happens inside Drupal's admin screen, the same as any other
Drupal site you may have used before.

## Publishing a new page or update

1. Log into the Drupal admin at `https://cms.vodacom.internal/user/login`.
2. Go to **Content → Add content** and pick the type (Page, Media release,
   Job listing, or Executive profile).
3. Fill in the fields. Anything marked required (like image alt text) must
   be filled in before you can publish — this keeps the site accessible and
   fast for every visitor.
4. Use the **language switcher** at the top of the edit form to add a
   translation once the English (or primary) version is ready. You don't
   need to translate everything at once — untranslated pages will
   automatically show the English version to visitors until you do.
5. Set the moderation state to **Published** (not just "Draft" or "Save").
6. That's it. The public site updates automatically within a couple of
   minutes — there's a short delay while the new page is built, similar to
   how a scheduled post works on other platforms.

## Building a page from sections (no design skills needed)

For Page content, instead of one big text box, you build the page by
adding **sections** — small building blocks you pick from a list, one at
a time. Under the "Sections" field, click **Add section** and choose from:

- **Rich text** — general paragraphs, headings, bullet lists
- **Related links grid** — a few image cards linking to other pages
- **Expandable card grid** — cards that open to show more (bios, topics)
- **Accordion** — a stack of collapsible sections
- **Process flow** — a numbered sequence of steps
- **Icon link grid** — small CTA cards with an icon
- **Callout banner** — a full-width colored message band
- **Document download list** — a list of PDF downloads
- **Related link list** — a plain list of "read more" links

Add as many sections as the page needs, in whatever order makes sense —
reorder them by dragging. You don't need to know what any of this looks
like in code; each one is already styled to match the rest of the site.

## Previewing before you publish

Before a page goes live, click **Preview** (not just Save). This opens
the page exactly as visitors will see it — same design, same layout —
with a pink "PREVIEW MODE" banner at the top so you know it's not live
yet. Share that preview link with whoever needs to approve it. Once
approved, go back and set the page to **Published**.

## Things to keep in mind

- **Images**: upload the best quality image you have — the system
  automatically compresses and resizes it for every visitor's device. You
  don't need to resize anything yourself.
- **Videos**: for hero/background videos, check with the web team before
  uploading anything over a couple of minutes long or above 1080p — long,
  high-resolution video is the single biggest thing that can slow the site
  down for visitors.
- **Alt text**: always describe what's in the image in plain language
  (e.g. "Vodacom customer service agent helping a customer in a store").
  This is required for both accessibility and search visibility.

## Who to contact

- Something looks broken on the live site → contact the web team, include
  the page URL and a screenshot.
- You want a new content type, section, or design change → that requires a
  developer, since it changes the page templates, not just content.
