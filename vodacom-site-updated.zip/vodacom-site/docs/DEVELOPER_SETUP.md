# Developer setup: from scratch

This is the single, ordered walkthrough for taking this repo from zero to a
live, editable, multilingual site. It supersedes any advice given earlier
in scattered form — if something here conflicts with an earlier message,
this doc wins.

Read `ARCHITECTURE.md` first if you haven't, for the "why" behind each
step. This doc is the "how."

---

## Part 1 — Drupal (content backend)

### 1.1 Install Drupal

```bash
composer create-project drupal/recommended-project vodacom-cms
cd vodacom-cms
```

Complete the web installer against a MySQL/MariaDB or PostgreSQL database.
Use a managed host (Pantheon, Acquia, Platform.sh) or your own
LAMP/LEMP stack.

### 1.2 Enable required core modules

```bash
drush en jsonapi language content_translation config_translation content_moderation -y
```

### 1.3 Add languages

**Configuration → Regional and language → Languages** — add French,
Portuguese, Swahili, Sesotho alongside the default English.

Then **Configuration → Regional and language → Content language** — tick
every content type you create in step 1.4 as translatable.

### 1.4 Create content types

Under **Structure → Content types**, create each type with the exact
field machine names below (these must match `fetch-drupal-content.mjs`
and `src/content/config.ts` exactly, or the sync script won't map them
correctly).

Full field-by-field spec: see `CONTENT_MODEL.md`. Types to create:
`Page`, `Media release`, `Investor event`, `Board member`,
`Executive profile`, `Job listing`.

**For `Page` specifically**, also add a field:

| Field | Machine name | Type |
|---|---|---|
| Sections | `field_sections` | Paragraphs (entity reference revisions), unlimited |

This is what makes pages composable. Create a **Paragraph type** for each
row in `CONTENT_MODEL.md`'s "Paragraphs / flexible sections" table (Rich
text, Related links grid, Expandable card grid, Accordion, Process flow,
Icon link grid, Callout banner, Document download list, Related link
list, Share price widget) — each with the fields listed there. Under
**Structure → Paragraphs types**, this is where editors get the
"pick a template, drop in content" experience: adding a `field_sections`
value to a page shows a dropdown of these paragraph types.

### 1.5 Configure JSON:API access

Visit `https://your-drupal-site/en/jsonapi/node/page` in a browser — you
should get JSON back. Anonymous JSON:API access defaults to read-only
published content, which is what you want; don't change that default.

### 1.6 Set up CORS

Edit `web/sites/default/default.services.yml` → copy to `services.yml` if
it doesn't exist → find `cors.config`, set:

```yaml
cors.config:
  enabled: true
  allowedOrigins: ['https://your-astro-build-domain.com']
  allowedHeaders: ['x-csrf-token', 'authorization', 'content-type', 'accept', 'origin', 'x-requested-with', 'access-control-allow-origin', 'x-preview-token']
  allowedMethods: ['GET']
```

### 1.7 Install the preview module

Copy `drupal-modules/vodacom_preview/` into your Drupal install's
`web/modules/custom/` directory, then:

```bash
drush en vodacom_preview -y
drush cset vodacom_preview.settings astro_base_url https://your-astro-site.com
```

Grant the **"Generate Vodacom preview links"** permission to your editor
role (**People → Permissions**). Editors will now see a **"Preview on live
site"** button on the edit form for any content type with a
`field_sections` field, which opens the real rendered draft on the Astro
site with a token valid for 1 hour (configurable via `token_ttl` in the
same config).

This module's `PreviewController::normalizeParagraph()` currently handles
the `rich_text` and `callout_banner` Paragraph types as working examples —
extend it with the remaining types (see the comment in that method) once
their Drupal field names are finalized in step 1.4.

### 1.8 Set up the publish webhook

Add a Rule (via the **Rules** module) or a small custom module hook that
fires **only on the transition to Published** (not on every save — drafts
shouldn't trigger a rebuild), sending a POST to your CI provider's build
hook URL (a Vercel/Netlify deploy hook, or a GitHub Actions
`repository_dispatch` event).

Test this manually first — `curl -X POST <your-deploy-hook-url>` — before
wiring it to Drupal, so you're not debugging two systems at once.

---

## Part 2 — Astro frontend

### 2.1 Install and configure

```bash
cd apps/vodacom-site
npm install
```

Set two environment variables (in `.env` locally, and in your hosting
platform's dashboard for production):

```
DRUPAL_BASE_URL=https://cms.vodacom.internal
PREVIEW_SECRET=<any random string, used to validate preview tokens>
```

### 2.2 Pull content and build

```bash
npm run sync-content   # pulls published content from Drupal into src/content/
npm run dev             # preview locally at localhost:4321
```

If `sync-content` fails, check (in order): `DRUPAL_BASE_URL` is reachable,
CORS is configured (step 1.6), and the JSON:API field names in Drupal
match `scripts/fetch-drupal-content.mjs`'s `ENTITY_MAP`.

### 2.3 Understand the page structure before adding a new page

Each page type has:
- **One template** in `src/templates/<Name>Template.astro` — the actual markup
- **Two thin wrappers**: `src/pages/<slug>.astro` (English, no prefix) and
  `src/pages/[lang]/<slug>.astro` (other locales, via `getStaticPaths`)

To add a new page type, copy the pattern from an existing one (e.g.
`AboutUsTemplate.astro` + `src/pages/about-us.astro` +
`src/pages/[lang]/about-us.astro`) rather than inventing a new structure.

**Do not** create a directory literally named `[[lang]]` — Astro doesn't
support optional-bracket directories; this scaffold hit that bug early on
and the template+wrapper pattern above is the fix.

### 2.4 Adding a new Paragraph/section type

1. Add the shape to `sectionSchema` in `src/content/config.ts`
2. Build the Astro component in `src/components/` (or `src/components/sections/`
   if it needs a remote-image-safe variant — see `RelatedLinksGridRemote.astro`
   for why some components need this)
3. Add one `case` to the `switch` in `src/components/SectionRenderer.astro`
4. Add the matching Paragraph type in Drupal (step 1.4)

Nothing else needs to change — every page template that renders
`<SectionRenderer sections={...} />` automatically supports the new type.

### 2.5 Build and verify

```bash
npm run build
```

Should exit 0. Static pages land in `.vercel/output/static/` (not `dist/`
— the Vercel serverless adapter changes this), and the preview function
bundles separately under `.vercel/output/functions/`. If you switch
hosting platforms, swap the adapter import in `astro.config.mjs` and this
path will change accordingly (Netlify/Cloudflare have their own
equivalents).

### 2.6 Deploy

Connect the repo to Vercel (or your chosen platform), set the same two
environment variables from step 2.1 there, and set the build command to:

```
npm run sync-content && npm run build
```

Every Drupal publish now triggers this automatically via the webhook from
step 1.8.

---

## Part 3 — Verify the whole loop works end to end

Do this once, in order, before considering the setup "done":

1. Create a test Page in Drupal with a couple of sections (e.g. a Rich
   text block + a Related links grid), leave it in **Draft**.
2. Click Preview → confirm you land on
   `your-astro-site.com/preview/<id>?token=...` and see the real rendered
   page, with the pink "PREVIEW MODE" banner at the top.
3. Publish it in Drupal.
4. Confirm the webhook fires (check your CI provider's build log).
5. Wait for the build to finish, then visit the real published URL and
   confirm the page appears — no banner, fully static.

If any step fails, the problem is isolated to that specific piece rather
than "something's wrong somewhere in the pipeline."
