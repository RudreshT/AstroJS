export type CardItem = { title: string; body?: string; href?: string };
export type StatItem = { label: string; value: string; note?: string };

export type LandingSection = {
  id: number;
  type: string;
  field_section_eyebrow?: string | null;
  field_section_title?: string | null;
  field_section_body?: string | null;
  cards?: CardItem[];
  stats?: StatItem[];
  field_cta_label?: string | null;
  field_cta_url?: { uri?: string; title?: string } | null;
};

export type LandingPage = {
  id: number;
  vid?: number;
  type: string;
  title: string;
  page_key: string;
  moderation_state?: string;
  changed?: number;
  hero_title: string;
  hero_subtitle: string;
  hero_cta_label: string;
  hero_cta_url: string;
  hero_image?: string | null;
  seo_description?: string;
  sections: LandingSection[];
  preview_url?: string;
};

const DRUPAL_URL = (import.meta.env.PUBLIC_DRUPAL_URL || 'https://sa-connectu.ddev.site').replace(/\/$/, '');
const PREVIEW_SECRET = import.meta.env.PUBLIC_PREVIEW_SECRET || 'change-me-sa-preview-secret';

function absoluteUrl(path: string): string {
  if (path.startsWith('http')) return path;
  return `${DRUPAL_URL}${path.startsWith('/') ? path : `/${path}`}`;
}

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T | null> {
  try {
    const res = await fetch(url, {
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init?.headers || {}),
      },
    });
    if (!res.ok) {
      console.warn(`[drupal] ${res.status} ${url}`);
      return null;
    }
    return (await res.json()) as T;
  } catch (err) {
    console.warn(`[drupal] fetch failed ${url}`, err);
    return null;
  }
}

/** Published landing page via custom-shaped preview serializer (works for published too). */
export async function getLandingByKey(pageKey: string): Promise<LandingPage | null> {
  const path = pageKey === 'home' ? '/home' : `/${pageKey}`;
  // Prefer JSON:API filter on published content
  const jsonApi = await fetchJson<{ data: any[] }>(
    `${DRUPAL_URL}/jsonapi/node/landing_page?filter[field_page_key]=${encodeURIComponent(pageKey)}&filter[status]=1&include=field_sections,field_sections.field_cards,field_sections.field_stats,field_hero_image&page[limit]=1`,
  );

  if (jsonApi?.data?.[0]) {
    return mapJsonApiLanding(jsonApi.data[0], jsonApi);
  }

  // Fallback to preview-by-path for local bootstrap when filters fail
  return fetchJson<LandingPage>(
    `${DRUPAL_URL}/sa-headless/preview-by-path?path=${encodeURIComponent(path)}&token=${encodeURIComponent(PREVIEW_SECRET)}`,
  );
}

export async function getPreviewLanding(opts: {
  nid?: string | null;
  path?: string | null;
  token?: string | null;
}): Promise<LandingPage | null> {
  const token = opts.token || PREVIEW_SECRET;
  if (opts.nid) {
    return fetchJson<LandingPage>(
      `${DRUPAL_URL}/sa-headless/preview/${opts.nid}?token=${encodeURIComponent(token)}`,
    );
  }
  const path = opts.path || '/home';
  return fetchJson<LandingPage>(
    `${DRUPAL_URL}/sa-headless/preview-by-path?path=${encodeURIComponent(path)}&token=${encodeURIComponent(token)}`,
  );
}

function mapJsonApiLanding(node: any, envelope: any): LandingPage {
  const attrs = node.attributes || {};
  const included = envelope.included || [];
  const rel = node.relationships || {};

  const findIncluded = (ref: { type: string; id: string } | undefined | null) =>
    ref ? included.find((i: any) => i.type === ref.type && i.id === ref.id) : null;

  const getNestedParagraphs = (resource: any, field: string) => {
    const data = resource.relationships?.[field]?.data;
    if (!data) return [];
    const refs = Array.isArray(data) ? data : [data];
    return refs.map((r: any) => findIncluded(r)).filter(Boolean);
  };

  const sectionRefs = rel.field_sections?.data || [];
  const sections: LandingSection[] = sectionRefs.map((ref: any) => {
    const para = findIncluded(ref);
    if (!para) return { id: 0, type: 'unknown' };
    const a = para.attributes || {};

    // Cards/stats are nested Paragraphs (card_item / stat_item), not raw
    // JSON text fields — this is what makes them editable by a
    // non-technical user in Drupal's normal "fill in a form, click Add
    // another" UI, instead of requiring hand-typed JSON syntax.
    const cards: CardItem[] = getNestedParagraphs(para, 'field_cards').map((c: any) => ({
      title: c.attributes?.field_card_title || '',
      body: c.attributes?.field_card_body || undefined,
      href: resolveHref(c.attributes?.field_card_href?.uri),
    }));
    const stats: StatItem[] = getNestedParagraphs(para, 'field_stats').map((s: any) => ({
      label: s.attributes?.field_stat_label || '',
      value: s.attributes?.field_stat_value || '',
      note: s.attributes?.field_stat_note || undefined,
    }));

    return {
      id: Number(a.drupal_internal__id || 0),
      type: (para.type || '').replace('paragraph--', ''),
      field_section_eyebrow: a.field_section_eyebrow,
      field_section_title: a.field_section_title,
      field_section_body: a.field_section_body?.value || a.field_section_body,
      cards,
      stats,
      field_cta_label: a.field_cta_label,
      field_cta_url: a.field_cta_url,
    };
  });

  let heroImage: string | null = null;
  const imgRel = rel.field_hero_image?.data;
  if (imgRel) {
    const file = findIncluded(imgRel);
    const uri = file?.attributes?.uri?.url;
    if (uri) heroImage = absoluteUrl(uri);
  }

  return {
    id: Number(attrs.drupal_internal__nid || 0),
    type: 'landing_page',
    title: attrs.title || '',
    page_key: attrs.field_page_key || '',
    moderation_state: attrs.moderation_state,
    hero_title: attrs.field_hero_title || attrs.title || '',
    hero_subtitle: attrs.field_hero_subtitle || '',
    hero_cta_label: attrs.field_hero_cta_label || '',
    hero_cta_url: attrs.field_hero_cta_url?.uri || '',
    hero_image: heroImage,
    seo_description: attrs.field_seo_description || '',
    sections,
  };
}

/** Convert Drupal link URIs (internal:/path, entity:, https:) to browser hrefs. */
export function resolveHref(uri?: string | null): string {
  if (!uri) return '#';
  if (uri.startsWith('internal:')) return uri.slice('internal:'.length) || '/';
  if (uri.startsWith('entity:node/')) return `/node/${uri.slice('entity:node/'.length)}`;
  if (uri.startsWith('route:')) return '#';
  return uri;
}

export { DRUPAL_URL, PREVIEW_SECRET };
