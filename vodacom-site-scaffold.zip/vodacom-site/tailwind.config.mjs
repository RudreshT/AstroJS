/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,ts,tsx,md,mdx}'],
  theme: {
    extend: {
      // Colors pulled directly from the reference design's tailwind.config
      // block, so the brand identity is preserved exactly, but this file is
      // compiled + purged at build time instead of shipping the whole
      // Tailwind runtime to the browser (that's what made the prototype slow).
      // Colors corrected to match the REAL site's actual brand red
      // (#e60000, confirmed from calendar.php's own inline CSS — the
      // legacy site is the authoritative source for brand identity).
      // The reference zip design used #ED1C24, a close AI-generated
      // approximation, not the real value — everything else here
      // (spacing, shadows, component polish) still follows that design's
      // direction, since the token is referenced everywhere rather than
      // hardcoded, this one fix corrects every component at once.
      colors: {
        vred: { DEFAULT: '#e60000', dark: '#a30000', light: '#ff2e2e' },
        vdark: { DEFAULT: '#25282B', 2: '#1A1A1A', 3: '#333840' },
        vgray: { 100: '#EBEBEB', 200: '#EDEDEF', 300: '#D1D1D6', 500: '#86868B', 700: '#4A4D4E' },
      },
      fontFamily: {
        vf: ['Vodafone', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
