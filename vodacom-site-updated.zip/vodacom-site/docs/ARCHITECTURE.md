# Architecture

```
 ┌─────────────┐   editor publishes   ┌──────────────┐
 │   Drupal     │ ───────────────────▶ │   Webhook     │
 │ (CMS, admin  │                      │  (CI trigger) │
 │  UI, JSON:API│                      └──────┬────────┘
 │  multilingual)│                             │
 └─────────────┘                              ▼
                                    ┌────────────────────┐
                                    │  Astro build        │
                                    │  1. fetch-drupal-    │
                                    │     content.mjs      │
                                    │  2. astro build       │
                                    │     (static HTML,     │
                                    │      per-locale)      │
                                    └──────────┬─────────┘
                                               ▼
                                    ┌────────────────────┐
                                    │  CDN (Cloudflare/    │
                                    │  Vercel/Netlify edge) │
                                    └──────────┬─────────┘
                                               ▼
                                          👤 Visitor
                                (gets static HTML/CSS,
                                 near-zero JS, from the
                                 nearest edge node —
                                 Drupal is never touched
                                 on this path)
```

## Why this hits 2 seconds reliably

The visitor's request path never touches PHP, a database query, or Drupal's
render pipeline. It's a static file served from an edge cache. The only
things that can slow it down are the things this repo controls directly:
image weight, font loading, and how much JS ships — all of which are
addressed in `docs/PERFORMANCE_BUDGET.md`.

## Why editors still get a normal CMS experience

Content editors never see Astro, GitHub, or a build pipeline. They log into
Drupal's admin UI exactly as they would for any Drupal site: create a page,
pick a language, use the media library, click **Publish**. The webhook and
rebuild happen automatically in the background. From their point of view,
"publish" takes effect within a couple of minutes (the time for the webhook
to fire and the static build to run) rather than instantly — that's the one
trade-off of this approach, and it's the right one for editorial content
(media releases, job listings, investor documents) that isn't time-critical
to the second.

## Multilingual approach

- Drupal core's `language`, `content_translation`, and `config_translation`
  modules manage translations per content type (see `CONTENT_MODEL.md`).
- `fetch-drupal-content.mjs` pulls every enabled locale from Drupal's
  language-prefixed JSON:API endpoints (`/fr/jsonapi/...`, `/pt/jsonapi/...`).
- Astro's built-in i18n routing (`astro.config.mjs`) generates one static
  page per locale per route, with `hreflang` tags so search engines serve
  the right language to the right visitor.
- UI chrome text (nav labels, buttons) lives in `src/i18n/ui.ts`, separate
  from CMS content, since it doesn't need an editor workflow.
- Untranslated content automatically falls back to English
  (`fallback` config in `astro.config.mjs`) rather than 404ing, so a language
  can be enabled incrementally as translations get done.

## The one dynamic exception: share price

Everything on the site is static except the live share price feed, which
is a third-party embed (Iress market data) exactly as it is on the current
vodacom.com. It's isolated in its own component (`SharePriceWidget.astro`)
and lazy-loaded so it can never block or slow down the rest of the page.
