<?php

namespace Drupal\vodacom_preview\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\KeyValueStore\KeyValueExpirableFactoryInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Generates and serves short-lived preview links for draft content.
 *
 * Deliberately uses the key/value expirable store rather than a custom
 * database table — tokens are small, short-lived (default 1 hour), and
 * this way there's no schema/update-hook to maintain.
 */
class PreviewController extends ControllerBase {

  protected KeyValueExpirableFactoryInterface $keyValueExpirableFactory;

  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->keyValueExpirableFactory = $container->get('keyvalue.expirable');
    return $instance;
  }

  /**
   * Generates a token for the given node and redirects to the Astro preview
   * route. Reached via a "Preview on live site" link on the node edit form.
   */
  public function generate(NodeInterface $node): RedirectResponse {
    $config = $this->config('vodacom_preview.settings');
    $baseUrl = rtrim((string) $config->get('astro_base_url'), '/');
    $ttl = (int) $config->get('token_ttl') ?: 3600;

    if (empty($baseUrl)) {
      throw new \RuntimeException('vodacom_preview.settings:astro_base_url is not configured. Set it with: drush cset vodacom_preview.settings astro_base_url https://your-astro-site.com');
    }

    $token = bin2hex(random_bytes(32));
    $store = $this->keyValueExpirableFactory->get('vodacom_preview');
    $store->setWithExpire($token, [
      'nid' => $node->id(),
      // Store the CURRENT (possibly unpublished) revision explicitly, so a
      // later edit to the node doesn't retroactively change what an
      // already-issued preview link shows.
      'vid' => $node->getRevisionId(),
    ], $ttl);

    $previewUrl = sprintf('%s/preview/%d?token=%s', $baseUrl, $node->id(), $token);
    return new RedirectResponse($previewUrl);
  }

  /**
   * Token-gated read of a node's (possibly draft) revision, in the shape
   * the Astro preview route (src/pages/preview/[id].astro) expects.
   */
  public function serve(NodeInterface $node, Request $request): Response {
    $token = $request->headers->get('X-Preview-Token') ?? $request->query->get('token');

    if (empty($token)) {
      return new JsonResponse(['error' => 'Missing preview token.'], 403);
    }

    $store = $this->keyValueExpirableFactory->get('vodacom_preview');
    $entry = $store->get($token);

    if (!$entry || (int) $entry['nid'] !== (int) $node->id()) {
      // Same error for "wrong node" and "expired/unknown token" —
      // deliberately not distinguishing, so a guesser can't use the error
      // message to enumerate valid node IDs.
      return new JsonResponse(['error' => 'Invalid or expired preview token.'], 403);
    }

    $storage = $this->entityTypeManager()->getStorage('node');
    $revision = $storage->loadRevision($entry['vid']);

    if (!$revision) {
      return new JsonResponse(['error' => 'The previewed revision no longer exists.'], 404);
    }

    return new JsonResponse($this->normalize($revision));
  }

  /**
   * Minimal hand-rolled normalizer — deliberately not reusing JSON:API's
   * normalizer here, since JSON:API's access checking assumes published
   * content and fighting that for one preview route added more complexity
   * than this plain array does. Keep this in sync with the field mapping
   * in scripts/fetch-drupal-content.mjs and src/pages/preview/[id].astro.
   */
  protected function normalize(NodeInterface $node): array {
    $sections = [];
    if ($node->hasField('field_sections')) {
      foreach ($node->get('field_sections') as $item) {
        $paragraph = $item->entity;
        if ($paragraph) {
          $sections[] = $this->normalizeParagraph($paragraph);
        }
      }
    }

    return [
      'title' => $node->getTitle(),
      'field_hero_headline' => $node->hasField('field_hero_headline') ? $node->get('field_hero_headline')->value : $node->getTitle(),
      'field_hero_subhead' => $node->hasField('field_hero_subhead') ? $node->get('field_hero_subhead')->value : NULL,
      'body' => $node->hasField('body') ? ['processed' => $node->get('body')->processed] : NULL,
      'field_sections' => $sections,
      'moderation_state' => $node->hasField('moderation_state') ? $node->get('moderation_state')->value : NULL,
    ];
  }

  /**
   * Normalizes one Paragraph entity into the shape SectionRenderer.astro
   * expects. Add a case here whenever a new Paragraph type is added in
   * Drupal — matching src/content/config.ts's sectionSchema.
   *
   * Repeating structured items (a grid of cards, a list of steps, etc.)
   * are modeled as NESTED Paragraphs — e.g. "expandable_card_grid" has a
   * field_cards entity-reference-revisions field pointing at
   * "expandable_card" paragraphs. This is the only native way in Drupal to
   * repeat a group of different field types (image + title + body) as one
   * unit — a multi-value plain field can't hold a mixed group like that.
   * See docs/CONTENT_MODEL.md's "Paragraphs / flexible sections" table for
   * the full nested-bundle list.
   */
  protected function normalizeParagraph($paragraph): array {
    $type = $paragraph->bundle();
    $get = fn(string $field) => $paragraph->hasField($field) && !$paragraph->get($field)->isEmpty()
      ? $paragraph->get($field)->value
      : NULL;
    $nested = fn(string $field) => $paragraph->hasField($field)
      ? $paragraph->get($field)->referencedEntities()
      : [];

    return match ($type) {
      'rich_text' => [
        'type' => 'richText',
        'html' => $get('field_body'),
      ],

      'related_links_grid' => [
        'type' => 'relatedLinksGrid',
        'heading' => $get('field_heading'),
        'cards' => array_map(fn($card) => [
          'image' => $this->resolveImage($card, 'field_image'),
          'label' => $card->hasField('field_label') ? $card->get('field_label')->value : '',
          'href' => $this->resolveLink($card, 'field_href'),
        ], $nested('field_cards')),
      ],

      'expandable_card_grid' => [
        'type' => 'expandableCardGrid',
        'heading' => $get('field_heading'),
        'columns' => (int) ($get('field_columns') ?: 2),
        'cards' => array_map(fn($card) => [
          'title' => $card->hasField('field_title') ? $card->get('field_title')->value : '',
          'subtitle' => $card->hasField('field_subtitle') ? $card->get('field_subtitle')->value : NULL,
          'image' => $this->resolveImage($card, 'field_image'),
          'imageShape' => $card->hasField('field_image_shape') ? ($card->get('field_image_shape')->value ?: 'square') : 'square',
          'body' => $card->hasField('field_body') ? $card->get('field_body')->value : '',
        ], $nested('field_cards')),
      ],

      'accordion' => [
        'type' => 'accordion',
        'items' => array_map(fn($item) => [
          'icon' => $item->hasField('field_icon') ? $item->get('field_icon')->value : NULL,
          'title' => $item->hasField('field_title') ? $item->get('field_title')->value : '',
          'teaser' => $item->hasField('field_teaser') ? $item->get('field_teaser')->value : '',
          'body' => $item->hasField('field_body') ? $item->get('field_body')->value : '',
        ], $nested('field_items')),
      ],

      'process_flow' => [
        'type' => 'processFlow',
        'steps' => array_map(fn($step) => [
          'title' => $step->hasField('field_title') ? $step->get('field_title')->value : '',
          'description' => $step->hasField('field_description') ? $step->get('field_description')->value : NULL,
        ], $nested('field_steps')),
      ],

      'icon_link_grid' => [
        'type' => 'iconLinkGrid',
        'heading' => $get('field_heading'),
        'items' => array_map(fn($item) => [
          'icon' => $item->hasField('field_icon') ? $item->get('field_icon')->value : '',
          'label' => $item->hasField('field_label') ? $item->get('field_label')->value : '',
          'href' => $this->resolveLink($item, 'field_href'),
          'external' => $item->hasField('field_external') ? (bool) $item->get('field_external')->value : FALSE,
        ], $nested('field_items')),
      ],

      'callout_banner' => [
        'type' => 'calloutBanner',
        'message' => $get('field_message'),
        'ctaLabel' => $get('field_cta_label'),
        'ctaHref' => $get('field_cta_href'),
        'tone' => $get('field_tone') ?: 'red',
      ],

      'document_download_list' => [
        'type' => 'documentDownloadList',
        'heading' => $get('field_heading'),
        'documents' => array_map(fn($doc) => [
          'label' => $doc->hasField('field_label') ? $doc->get('field_label')->value : '',
          'href' => $this->resolveFile($doc, 'field_file'),
          'fileSize' => $doc->hasField('field_file') ? $this->resolveFileSize($doc, 'field_file') : NULL,
        ], $nested('field_documents')),
      ],

      'related_link_list' => [
        'type' => 'relatedLinkList',
        'links' => array_map(fn($link) => [
          'label' => $link->hasField('field_label') ? $link->get('field_label')->value : '',
          'href' => $this->resolveLink($link, 'field_href'),
        ], $nested('field_links')),
      ],

      'share_price_widget' => [
        'type' => 'sharePriceWidget',
      ],

      default => [
        'type' => 'richText',
        'html' => '<p><em>Preview not yet implemented for paragraph type: ' . $type . '</em></p>',
      ],
    };
  }

  /**
   * Resolves an image field (referencing a Media entity of type Image)
   * into the {src, alt, width, height} shape the Astro side expects.
   */
  protected function resolveImage($entity, string $field): ?array {
    if (!$entity->hasField($field) || $entity->get($field)->isEmpty()) {
      return NULL;
    }
    $media = $entity->get($field)->entity;
    if (!$media || !$media->hasField('field_media_image') || $media->get('field_media_image')->isEmpty()) {
      return NULL;
    }
    $imageItem = $media->get('field_media_image')->first();
    $file = $imageItem->entity ?? NULL;
    if (!$file) {
      return NULL;
    }
    return [
      'src' => \Drupal::service('file_url_generator')->generateAbsoluteString($file->getFileUri()),
      'alt' => (string) ($imageItem->alt ?? ''),
      'width' => (int) ($imageItem->width ?? 0),
      'height' => (int) ($imageItem->height ?? 0),
    ];
  }

  /**
   * Resolves a Link field into an absolute URL string.
   */
  protected function resolveLink($entity, string $field): string {
    if (!$entity->hasField($field) || $entity->get($field)->isEmpty()) {
      return '';
    }
    try {
      return $entity->get($field)->first()->getUrl()->setAbsolute()->toString();
    }
    catch (\Exception $e) {
      // Falls back to the raw URI (e.g. for external links Drupal's
      // routing system can't resolve as an internal route).
      return (string) ($entity->get($field)->uri ?? '');
    }
  }

  /**
   * Resolves a File field into an absolute download URL.
   */
  protected function resolveFile($entity, string $field): string {
    if (!$entity->hasField($field) || $entity->get($field)->isEmpty()) {
      return '';
    }
    $file = $entity->get($field)->entity ?? NULL;
    return $file ? \Drupal::service('file_url_generator')->generateAbsoluteString($file->getFileUri()) : '';
  }

  /**
   * Human-readable file size (e.g. "223KB") for the document download list.
   */
  protected function resolveFileSize($entity, string $field): ?string {
    $file = $entity->hasField($field) && !$entity->get($field)->isEmpty() ? $entity->get($field)->entity : NULL;
    if (!$file) {
      return NULL;
    }
    $bytes = (int) $file->getSize();
    if ($bytes >= 1048576) {
      return round($bytes / 1048576, 1) . 'MB';
    }
    return round($bytes / 1024) . 'KB';
  }

}
