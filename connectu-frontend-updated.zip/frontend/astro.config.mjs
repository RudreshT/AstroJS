// @ts-check
import { defineConfig } from 'astro/config';
import tailwindcss from '@tailwindcss/vite';
import node from '@astrojs/node';

// Public pages are prerendered (static) for ~1s delivery on slow networks.
// Preview routes set `prerender = false` and use the Node adapter.
export default defineConfig({
  output: 'static',
  adapter: node({
    mode: 'standalone',
  }),
  vite: {
    plugins: [tailwindcss()],
  },
  server: {
    port: 4321,
    host: true,
  },
});
