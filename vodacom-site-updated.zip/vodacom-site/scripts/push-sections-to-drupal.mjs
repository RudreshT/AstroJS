#!/usr/bin/env node
/**
 * Stage 2 of the content import pipeline: takes a reviewed JSON file
 * (produced by extract-webpage-content.mjs, THEN corrected by a human) and
 * writes it into Drupal as a Page node with nested Paragraph entities via
 * JSON:API.
 *
 * SAFETY: defaults to --dry-run (prints exactly what it would create/send,
 * writes nothing). You must pass --apply explicitly to actually write to
 * Drupal. Always run against a TEST page first.
 *
 * Requires a dedicated Drupal API user with ONLY "Create/edit Page content"
 * and "Create [each paragraph bundle]" permissions — not an admin account.
 * Set credentials via env vars, never pass them on the command line where
 * they'd end up in shell history.
 *
 * Usage:
 *   DRUPAL_BASE_URL=https://newvodacomsite.ddev.site \
 *   DRUPAL_API_USER=content-importer \
 *   DRUPAL_API_PASS=xxx \
 *   node scripts/push-sections-to-drupal.mjs content-import/home.json --apply
 *
 * KNOWN LIMITATION: this has NOT been tested against a live Drupal
 * instance (no reachable Drupal instance in the environment this was
 * written in) — the JSON:API request shapes follow Drupal's documented
 * write format, but treat this as a starting point to debug against your
 * actual instance, not a guaranteed-working tool. Run --dry-run first,
 * read the output carefully, and test on a throwaway page before trusting
 * it with real content.
 */
import { readFile } from 'node:fs/promises';

const filePath = process.argv[2];
const APPLY = process.argv.includes('--apply');

if (!filePath) {
  console.error('Usage: node scripts/push-sections-to-drupal.mjs <reviewed-file.json> [--apply]');
  process.exit(1);
}

const DRUPAL_BASE_URL = process.env.DRUPAL_BASE_URL || 'https://example-drupal-site.test';
const DRUPAL_API_USER = process.env.DRUPAL_API_USER || 'dry-run-placeholder';
const DRUPAL_API_PASS = process.env.DRUPAL_API_PASS || 'dry-run-placeholder';

if (APPLY && (!process.env.DRUPAL_BASE_URL || !process.env.DRUPAL_API_USER || !process.env.DRUPAL_API_PASS)) {
  console.error('Missing DRUPAL_BASE_URL, DRUPAL_API_USER, or DRUPAL_API_PASS environment variables — required when using --apply.');
  process.exit(1);
}

const authHeader = 'Basic ' + Buffer.from(`${DRUPAL_API_USER}:${DRUPAL_API_PASS}`).toString('base64');

// Maps our section `type` to the Drupal Paragraph bundle machine name —
// must match docs/CONTENT_MODEL.md exactly.
const BUNDLE_MAP = {
  richText: 'rich_text',
  relatedLinksGrid: 'related_links_grid',
  expandableCardGrid: 'expandable_card_grid',
  accordion: 'accordion',
  processFlow: 'process_flow',
  iconLinkGrid: 'icon_link_grid',
  calloutBanner: 'callout_banner',
  documentDownloadList: 'document_download_list',
  relatedLinkList: 'related_link_list',
  sharePriceWidget: 'share_price_widget',
};

let csrfToken = null;

async function getCsrfToken() {
  if (csrfToken) return csrfToken;
  const res = await fetch(`${DRUPAL_BASE_URL}/session/token`, {
    headers: { Authorization: authHeader },
  });
  if (!res.ok) throw new Error(`Could not fetch CSRF token (${res.status}) — is the API user's password correct?`);
  csrfToken = await res.text();
  return csrfToken;
}

async function drupalRequest(method, path, body) {
  const token = await getCsrfToken();
  const res = await fetch(`${DRUPAL_BASE_URL}${path}`, {
    method,
    headers: {
      Authorization: authHeader,
      'Content-Type': 'application/vnd.api+json',
      Accept: 'application/vnd.api+json',
      'X-CSRF-Token': token,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(`Drupal request failed (${res.status}) ${method} ${path}: ${JSON.stringify(json?.errors ?? json)}`);
  }
  return json;
}

/** Creates one Paragraph entity (and recursively its nested items/cards),
 * returning the {type, id, meta: {target_revision_id}} reference Drupal
 * needs for the parent's entity-reference-revisions field. */
async function createParagraph(section) {
  const bundle = BUNDLE_MAP[section.type];
  if (!bundle) throw new Error(`Unknown section type: ${section.type}`);

  const attributes = {};
  const relationships = {};

  switch (section.type) {
    case 'richText':
      attributes.field_body = section.html;
      break;

    case 'relatedLinksGrid': {
      attributes.field_heading = section.heading;
      const cardRefs = [];
      for (const card of section.cards) {
        // NOTE: image upload is NOT automated here — this assumes
        // card.image.src already points at an image already present in
        // Drupal's media library (a media UUID lookup would go here).
        // Uploading arbitrary external image URLs into Drupal's file
        // system is a separate, riskier operation (fetching untrusted
        // remote files) intentionally left as a manual step.
        console.warn(`  [manual step needed] card "${card.label}" image (${card.image?.src}) must be attached to the link_card paragraph by hand in Drupal — image upload is not automated by this script.`);
        const cardRef = await createNestedParagraph('link_card', {
          field_label: card.label,
          field_href: { uri: card.href },
        });
        cardRefs.push(cardRef);
      }
      relationships.field_cards = { data: cardRefs };
      break;
    }

    case 'relatedLinkList': {
      const linkRefs = [];
      for (const link of section.links) {
        linkRefs.push(await createNestedParagraph('link_item', {
          field_label: link.label,
          field_href: { uri: link.href },
        }));
      }
      relationships.field_links = { data: linkRefs };
      break;
    }

    case 'calloutBanner':
      attributes.field_message = section.message;
      attributes.field_cta_label = section.ctaLabel;
      if (section.ctaHref) attributes.field_cta_href = { uri: section.ctaHref };
      attributes.field_tone = section.tone ?? 'red';
      break;

    // expandableCardGrid, accordion, processFlow, iconLinkGrid,
    // documentDownloadList: same nested-paragraph pattern as
    // relatedLinksGrid/relatedLinkList above — not filled in here since
    // extract-webpage-content.mjs doesn't currently produce these types
    // (a generic webpage scrape rarely maps cleanly to a process-flow or
    // accordion; those are better authored directly in Drupal). Add a
    // case here follwing the same shape if you extend the extractor.
    case 'sharePriceWidget':
      break;

    default:
      throw new Error(`createParagraph: section type "${section.type}" not yet implemented in the push script.`);
  }

  return submitParagraph(bundle, attributes, relationships);
}

async function createNestedParagraph(bundle, attributes) {
  return submitParagraph(bundle, attributes, {});
}

async function submitParagraph(bundle, attributes, relationships) {
  const payload = {
    data: {
      type: `paragraph--${bundle}`,
      attributes,
      ...(Object.keys(relationships).length ? { relationships } : {}),
    },
  };

  if (!APPLY) {
    console.log(`[dry-run] would POST /jsonapi/paragraph/${bundle}`, JSON.stringify(payload, null, 2));
    return { type: `paragraph--${bundle}`, id: `dry-run-${bundle}-${Math.random().toString(36).slice(2, 8)}`, meta: { target_revision_id: 0 } };
  }

  const result = await drupalRequest('POST', `/jsonapi/paragraph/${bundle}`, payload);
  return {
    type: result.data.type,
    id: result.data.id,
    meta: { target_revision_id: result.data.attributes.drupal_internal__revision_id },
  };
}

async function run() {
  const raw = await readFile(filePath, 'utf-8');
  const draft = JSON.parse(raw);

  if (draft._instructions) {
    console.log('This file still contains the review instructions banner.');
    console.log('Make sure you actually reviewed the content before proceeding.\n');
  }

  console.log(`${APPLY ? 'APPLYING' : 'DRY RUN (pass --apply to actually write)'}: ${draft.sections.length} section(s) for page "${draft.title}" (slug: ${draft.slug})\n`);

  const sectionRefs = [];
  for (const section of draft.sections) {
    if (section.reviewNote) {
      console.log(`Processing section [${section.type}] — had review note: "${section.reviewNote}"`);
    }
    const ref = await createParagraph(section);
    sectionRefs.push(ref);
  }

  const pagePayload = {
    data: {
      type: 'node--page',
      attributes: {
        title: draft.title,
        path: { alias: `/${draft.slug}` },
        moderation_state: 'draft', // ALWAYS lands as draft, never auto-published
      },
      relationships: {
        field_sections: { data: sectionRefs },
      },
    },
  };

  if (!APPLY) {
    console.log('\n[dry-run] would POST /jsonapi/node/page', JSON.stringify(pagePayload, null, 2));
    console.log('\nNo changes were made. Review the output above, then re-run with --apply.');
    return;
  }

  const result = await drupalRequest('POST', '/jsonapi/node/page', pagePayload);
  console.log(`\nCreated Page node ${result.data.id} as a DRAFT — go to Drupal, review it, and click Publish when ready.`);
}

run().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
