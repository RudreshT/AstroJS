import { defineCollection, z } from 'astro:content';

// These schemas mirror the Drupal content types defined in
// docs/CONTENT_MODEL.md. Content is synced from Drupal's JSON:API into
// src/content/{collection}/{lang}/*.json by scripts/fetch-drupal-content.mjs
// (run in CI on every editor publish, via webhook) — Astro then builds
// fully static pages from these local files. No Drupal PHP runtime is
// touched on the visitor's request path.

const mediaImage = z.object({
  src: z.string(),
  alt: z.string(), // required — Drupal enforces alt text on every image field for a11y
  width: z.number(),
  height: z.number(),
});

// ---------------------------------------------------------------------
// Flexible sections (Drupal Paragraphs equivalent) — see docs/CONTENT_MODEL.md
// "Paragraphs / flexible sections" for the full catalog and when an editor
// picks each one. A Page can carry a `sections` array built from these, in
// addition to (or instead of) the single `body` field, so editors compose
// pages from reusable blocks rather than being locked into one layout.
// ---------------------------------------------------------------------
const linkSchema = z.object({ label: z.string(), href: z.string() });

const sectionSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('richText'), html: z.string() }),
  z.object({
    type: z.literal('relatedLinksGrid'),
    heading: z.string().optional(),
    cards: z.array(z.object({ image: mediaImage, label: z.string(), href: z.string() })),
  }),
  z.object({
    type: z.literal('expandableCardGrid'),
    heading: z.string().optional(),
    columns: z.union([z.literal(2), z.literal(3)]).default(2),
    cards: z.array(z.object({
      title: z.string(),
      subtitle: z.string().optional(),
      image: mediaImage.optional(),
      imageShape: z.enum(['circle', 'square']).default('square'),
      body: z.string(),
    })),
  }),
  z.object({
    type: z.literal('accordion'),
    items: z.array(z.object({
      icon: z.string().optional(),
      title: z.string(),
      teaser: z.string(),
      body: z.string(),
    })),
  }),
  z.object({
    type: z.literal('processFlow'),
    steps: z.array(z.object({ title: z.string(), description: z.string().optional() })),
  }),
  z.object({
    type: z.literal('iconLinkGrid'),
    heading: z.string().optional(),
    items: z.array(z.object({ icon: z.string(), label: z.string(), href: z.string(), external: z.boolean().default(false) })),
  }),
  z.object({
    type: z.literal('calloutBanner'),
    message: z.string(),
    ctaLabel: z.string().optional(),
    ctaHref: z.string().optional(),
    tone: z.enum(['red', 'dark']).default('red'),
  }),
  z.object({
    type: z.literal('documentDownloadList'),
    heading: z.string().optional(),
    documents: z.array(z.object({ label: z.string(), href: z.string(), fileSize: z.string().optional() })),
  }),
  z.object({ type: z.literal('relatedLinkList'), links: z.array(linkSchema) }),
  z.object({ type: z.literal('sharePriceWidget') }),
]);
export type Section = z.infer<typeof sectionSchema>;

const page = defineCollection({
  type: 'data',
  schema: z.object({
    drupalId: z.string(),
    lang: z.string(),
    translationOf: z.string().optional(), // links translated variants together
    title: z.string(),
    slug: z.string(),
    heroHeadline: z.string(),
    heroSubhead: z.string().optional(),
    heroImage: mediaImage.optional(),
    heroVideo: z
      .object({
        poster: mediaImage,
        mp4: z.string(),
        webm: z.string().optional(),
      })
      .optional(),
    body: z.string().optional(), // legacy single-field pages (still supported)
    sections: z.array(sectionSchema).optional(), // Paragraphs-composed pages
    seoTitle: z.string().optional(),
    seoDescription: z.string().optional(),
    updatedAt: z.string(),
  }),
});

const mediaRelease = defineCollection({
  type: 'data',
  // Expanded to match the fields actually used by the legacy `articles`
  // table (seen in includes/latest-news.php): category/subcategory,
  // featured flag, source, an optional external link (some releases point
  // off-site rather than to a local article page), and an optional
  // downloadable document instead of/alongside body copy.
  schema: z.object({
    drupalId: z.string(),
    lang: z.string(),
    title: z.string(),
    slug: z.string(),
    publishedAt: z.string(),
    intro: z.string(),
    body: z.string().optional(),
    smallImage: mediaImage.optional(),
    largeImage: mediaImage.optional(),
    caption1: z.string().optional(),
    smallImage2: mediaImage.optional(),
    largeImage2: mediaImage.optional(),
    caption2: z.string().optional(),
    document: z.object({ url: z.string(), fileSize: z.string().optional() }).optional(),
    externalLink: z.string().optional(),
    source: z.string().optional(),
    category: z.string(),
    subcategory: z.string().optional(),
    featured: z.boolean().default(false),
    disclaimer: z.string().optional(),
  }),
});

// New: investor events (was a raw MySQL `calendarEvent` table query in the
// legacy calendar.php — now a normal editable content type).
const investorEvent = defineCollection({
  type: 'data',
  schema: z.object({
    drupalId: z.string(),
    lang: z.string(),
    title: z.string(),
    eventStart: z.string(), // ISO date
    eventEnd: z.string().optional(),
    location: z.string().default('Online'),
    time: z.string().optional(),
  }),
});

// New: board of directors, split from Executive profile. Legacy
// board-of-directors.php shows these need age, qualifications, a list of
// committee memberships, and a longer bio than an exec profile card.
const boardMember = defineCollection({
  type: 'data',
  schema: z.object({
    drupalId: z.string(),
    lang: z.string(),
    name: z.string(),
    age: z.number().optional(),
    role: z.string(), // e.g. "Independent non-executive chairman"
    qualifications: z.string().optional(),
    committees: z.array(z.string()).default([]),
    photo: mediaImage,
    bio: z.string(),
    order: z.number().default(0),
  }),
});

const jobListing = defineCollection({
  type: 'data',
  schema: z.object({
    drupalId: z.string(),
    lang: z.string(),
    title: z.string(),
    slug: z.string(),
    location: z.string(),
    department: z.string(),
    closingDate: z.string().optional(),
    applyUrl: z.string(), // usually deep-links to careers.vodafone.com ATS
    body: z.string(),
  }),
});

const executiveProfile = defineCollection({
  type: 'data',
  schema: z.object({
    drupalId: z.string(),
    lang: z.string(),
    name: z.string(),
    role: z.string(),
    photo: mediaImage,
    bio: z.string(),
    order: z.number().default(0),
  }),
});

export const collections = {
  page,
  'media-release': mediaRelease,
  'job-listing': jobListing,
  'executive-profile': executiveProfile,
  'investor-event': investorEvent,
  'board-member': boardMember,
};
