# Performance budget

Target: **Largest Contentful Paint (LCP) under 1.5s, full page interactive
under 1.5s**, on a simulated "Slow 4G" mobile connection (the standard
Lighthouse mobile test profile) — this is a stricter bar than "1.5 seconds
on a fast office wifi," and is the right one to build to since a
meaningful share of visitors across Vodacom's African markets are on
constrained mobile connections.

This is achievable specifically *because* every public page is static
HTML served from a CDN edge node — there's no server, database, or PHP
runtime in the request path to add latency (see `ARCHITECTURE.md`). The
things that can still blow this budget are entirely within this repo's
control: image weight, font loading, and how much JS ships — covered below.

## Budget per page

| Resource            | Budget      | How it's enforced |
|----------------------|-------------|---------------------|
| Total transferred     | ≤ 1.2 MB    | CI fails build if `dist/` page weight exceeds this (see below) |
| JS shipped to browser | ≤ 60 KB     | Astro ships zero JS by default; only explicit islands (language switcher needs none, share price widget is a small vanilla script) add any |
| CSS                   | ≤ 40 KB     | Tailwind purges unused classes at build time (vs. the ~300KB+ unpurged Tailwind CDN build in the reference prototype) |
| LCP image/video poster| ≤ 150 KB    | AVIF/WebP via Astro's Image component, responsive `srcset`, `fetchpriority="high"` |
| Fonts                 | ≤ 100 KB total | Self-hosted woff2, `font-display: swap`, only the 2 weights actually used are loaded |
| Hero video (if played) | ≤ 3 MB, loads AFTER first paint | Deferred via `IntersectionObserver`, skipped on `Save-Data`/slow connections/reduced motion |

## What changed vs. the reference prototype

| Prototype (zip)                          | This build |
|--------------------------------------------|--------------|
| `cdn.tailwindcss.com` (runtime compiler)    | Tailwind compiled + purged at build time |
| GSAP + ScrollTrigger + D3 + TopoJSON, always loaded | Removed by default; add back only for a specific page as a scoped island, if a specific animation is truly needed |
| 3 autoplay hero videos, 7.5–26 MB each      | Videos re-encoded, capped at 3 MB, deferred, poster image is the real LCP element |
| Team photos as unoptimized PNGs (450–780 KB)| Converted to AVIF/WebP via Astro Image, ~30–80 KB each |
| Images from Unsplash/Pexels live CDNs       | All imagery self-hosted / served from the project's own CDN |
| No `<link>` stylesheets — everything inlined into a 264 KB HTML file | Normal CSS build, cacheable across page loads |

## Pre-launch checklist

- [ ] Re-encode all hero/section videos: H.264, target bitrate for ≤3MB at
      15-20s loop length, 1080p max
- [ ] Convert `VodafoneRg.woff` and `vodafonergbd-webfont.woff` to `.woff2`
- [ ] Run every template through Lighthouse CI in the build pipeline; fail
      the build below a score of 90 (mobile) rather than catching
      regressions after deploy
- [ ] Confirm CDN cache headers: static assets (`/fonts`, `/images`,
      `/videos`, hashed JS/CSS) set `Cache-Control: immutable, max-age=1y`
- [ ] Set `loading="lazy"` on every image below the fold (Astro's `<Image>`
      does this by default for non-priority images)
- [ ] Verify third-party iframe (share price widget) never appears in the
      Lighthouse "render-blocking resources" report
- [ ] **Handle Drupal-sourced images separately from build-time assets**
      (see note below) — director/executive photos, media release images,
      and any other content-editor-uploaded media come from Drupal at
      build time as remote URLs, not local files Astro can re-encode with
      its built-in `<Image>` component the way the marketing/hero imagery
      is. Without action here, these images ship as whatever format/size
      the editor originally uploaded — a real risk to the budget once
      editors are uploading their own photos.

### Handling Drupal-sourced (editor-uploaded) images

Two options, in order of preference:

1. **Configure Drupal's own image styles** (`Configuration → Media →
   Image styles`) to output WebP at a few standard widths, and have
   `fetch-drupal-content.mjs` request those derivative URLs rather than the
   original upload. This keeps optimization entirely on the Drupal side —
   no extra service needed.
2. **Put an image CDN in front of Drupal's media** (Cloudflare Images,
   imgix, or similar) that resizes/re-encodes on the fly from a URL
   pattern. More flexible (responsive `srcset` generated automatically),
   at the cost of one more service to operate.

Either way, enforce a sane upload ceiling in Drupal (recommend capping
originals at 2400px wide) so a 12MB phone photo can't slip through as
someone's headshot.

## Ongoing enforcement

Add a budget check to CI (e.g. `@astrojs/check` + a simple script comparing
`dist/**/*.html` + linked asset sizes against the table above, or a
Lighthouse CI `budgets.json`) so a future content or dependency change that
regresses performance fails the build instead of quietly shipping.
